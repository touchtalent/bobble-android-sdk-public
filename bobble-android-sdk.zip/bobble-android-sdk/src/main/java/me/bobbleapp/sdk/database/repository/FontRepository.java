package me.bobbleapp.sdk.database.repository;

import android.content.Context;

import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.Font;
import me.bobbleapp.sdk.database.FontDao;

public class FontRepository {

    public static void insertOrUpdate(Context context, Font font) {
        getFontDao(context).insertOrReplace(font);
    }

    public static void clearFonts(Context context) {
        getFontDao(context).deleteAll();
    }

    public static boolean isEmpty(Context context) {
        return (getFontDao(context).count() == 0);
    }

    public static void deleteFontWithId(Context context, long id) {
        getFontDao(context).delete(getFontForId(context, id));
    }

    public static List<Font> getAllFonts(Context context) {
        return getFontDao(context).loadAll();
    }

    public static Font getFontForId(Context context, long id) {
        return getFontDao(context).load(id);
    }

    public static FontDao getFontDao(Context c) {
        return BobbleSDK.getDaoSession().getFontDao();
    }
}
