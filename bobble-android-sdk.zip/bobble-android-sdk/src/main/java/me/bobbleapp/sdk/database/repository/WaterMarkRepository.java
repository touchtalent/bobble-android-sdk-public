package me.bobbleapp.sdk.database.repository;

import android.content.Context;
import android.database.sqlite.SQLiteDatabaseLockedException;

import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.WaterMark;
import me.bobbleapp.sdk.database.WaterMarkDao;

/**
 * Created by amitshekhar on 04/02/15.
 */
public class WaterMarkRepository {

    public static void insertOrUpdate(Context context, WaterMark waterMark) {
        try {
            getWaterMarkDao(context).insertOrReplace(waterMark);
        } catch (SQLiteDatabaseLockedException e) {
            e.printStackTrace();
        }
    }

    public static void clearWaterMark(Context context) {
        try {
            getWaterMarkDao(context).deleteAll();
        } catch (SQLiteDatabaseLockedException e) {
            e.printStackTrace();
        }
    }

    public static boolean isEmpty(Context context) {
        try {
            return (getWaterMarkDao(context).count() == 0);
        } catch (SQLiteDatabaseLockedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public static void deleteWaterMarkWithImageUrl(Context context, String imageUrl) {
        getWaterMarkDao(context).delete(getWaterMarkForImageUrl(context, imageUrl));
    }

    public static List<WaterMark> getAllWaterMark(Context context) {
        return getWaterMarkDao(context).loadAll();
    }

    public static WaterMark getWaterMarkForImageUrl(Context context, String imageUrl) {
        return getWaterMarkDao(context).load(imageUrl);
    }

    public static WaterMarkDao getWaterMarkDao(Context c) {
        return BobbleSDK.getDaoSession().getWaterMarkDao();
    }
}
