package me.bobbleapp.sdk.model;

/**
 * Created by amitshekhar on 22/01/16.
 */
public class ApiStickerCharacter {

    private long stickerCharacterId;
    private String stickerCharacterImageHDPI;
    private String stickerCharacterImageXHDPI;
    private String stickerCharacterImageXXHDPI;
    private String stickerCharacterImage;
    private float stickerCharacterFaceX;
    private float stickerCharacterFaceY;
    private float stickerCharacterFaceAngle;
    private int stickerCharacterTextLeft;
    private int stickerCharacterTextTop;
    private int stickerCharacterTextBottom;
    private int stickerCharacterTextRight;
    private float stickerCharacterTextAngle;
    private Integer stickerCharacterFaceHeight;


    public long getStickerCharacterId() {
        return stickerCharacterId;
    }

    public void setStickerCharacterId(long stickerCharacterId) {
        this.stickerCharacterId = stickerCharacterId;
    }

    public String getStickerCharacterImageHDPI() {
        return stickerCharacterImageHDPI;
    }

    public void setStickerCharacterImageHDPI(String stickerCharacterImageHDPI) {
        this.stickerCharacterImageHDPI = stickerCharacterImageHDPI;
    }

    public String getStickerCharacterImageXHDPI() {
        return stickerCharacterImageXHDPI;
    }

    public void setStickerCharacterImageXHDPI(String stickerCharacterImageXHDPI) {
        this.stickerCharacterImageXHDPI = stickerCharacterImageXHDPI;
    }

    public String getStickerCharacterImageXXHDPI() {
        return stickerCharacterImageXXHDPI;
    }

    public void setStickerCharacterImageXXHDPI(String stickerCharacterImageXXHDPI) {
        this.stickerCharacterImageXXHDPI = stickerCharacterImageXXHDPI;
    }

    public String getStickerCharacterImage() {
        return stickerCharacterImage;
    }

    public void setStickerCharacterImage(String stickerCharacterImage) {
        this.stickerCharacterImage = stickerCharacterImage;
    }

    public float getStickerCharacterFaceX() {
        return stickerCharacterFaceX;
    }

    public void setStickerCharacterFaceX(float stickerCharacterFaceX) {
        this.stickerCharacterFaceX = stickerCharacterFaceX;
    }

    public float getStickerCharacterFaceY() {
        return stickerCharacterFaceY;
    }

    public void setStickerCharacterFaceY(float stickerCharacterFaceY) {
        this.stickerCharacterFaceY = stickerCharacterFaceY;
    }

    public float getStickerCharacterFaceAngle() {
        return stickerCharacterFaceAngle;
    }

    public void setStickerCharacterFaceAngle(float stickerCharacterFaceAngle) {
        this.stickerCharacterFaceAngle = stickerCharacterFaceAngle;
    }

    public int getStickerCharacterTextLeft() {
        return stickerCharacterTextLeft;
    }

    public void setStickerCharacterTextLeft(int stickerCharacterTextLeft) {
        this.stickerCharacterTextLeft = stickerCharacterTextLeft;
    }

    public int getStickerCharacterTextTop() {
        return stickerCharacterTextTop;
    }

    public void setStickerCharacterTextTop(int stickerCharacterTextTop) {
        this.stickerCharacterTextTop = stickerCharacterTextTop;
    }

    public int getStickerCharacterTextBottom() {
        return stickerCharacterTextBottom;
    }

    public void setStickerCharacterTextBottom(int stickerCharacterTextBottom) {
        this.stickerCharacterTextBottom = stickerCharacterTextBottom;
    }

    public int getStickerCharacterTextRight() {
        return stickerCharacterTextRight;
    }

    public void setStickerCharacterTextRight(int stickerCharacterTextRight) {
        this.stickerCharacterTextRight = stickerCharacterTextRight;
    }

    public float getStickerCharacterTextAngle() {
        return stickerCharacterTextAngle;
    }

    public void setStickerCharacterTextAngle(float stickerCharacterTextAngle) {
        this.stickerCharacterTextAngle = stickerCharacterTextAngle;
    }

    public Integer getStickerCharacterFaceHeight() {
        return stickerCharacterFaceHeight;
    }

    public void setStickerCharacterFaceHeight(Integer stickerCharacterFaceHeight) {
        this.stickerCharacterFaceHeight = stickerCharacterFaceHeight;
    }
}
