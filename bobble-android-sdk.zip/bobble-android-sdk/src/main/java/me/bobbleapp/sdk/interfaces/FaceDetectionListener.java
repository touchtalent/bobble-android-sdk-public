package me.bobbleapp.sdk.interfaces;

import android.graphics.RectF;

import java.util.List;

/**
 * Created by amitshekhar on 16/01/16.
 */
public interface FaceDetectionListener {

    void onSingleFaceDetection(RectF faceRectF);

    void onMultipleFaceDetection(List<RectF> facesRectFList);

    void onNoFaceDetection();

    void onError(String error);

}
