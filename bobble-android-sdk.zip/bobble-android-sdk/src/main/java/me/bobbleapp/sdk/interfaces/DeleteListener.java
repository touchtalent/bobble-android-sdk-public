package me.bobbleapp.sdk.interfaces;

/**
 * Created by amitshekhar on 23/06/16.
 */
public interface DeleteListener {

    void onDeleteCompletion();

    void onError(String error);
}
