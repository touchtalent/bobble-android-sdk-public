package me.bobbleapp.sdk.view;

/**
 * Created by amitshekhar on 25/07/16.
 */

import android.content.Context;

public interface BaseView {

    Context context();
}
