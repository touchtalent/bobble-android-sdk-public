
package me.bobbleapp.sdk.faceselector.cropwindow.handle;

import android.graphics.Rect;

import me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge;

/**
 * Handle helper class to handle horizontal handles (i.e. top and bottom
 * handles).
 */
class HorizontalHandleHelper extends HandleHelper {

    // Member Variables ////////////////////////////////////////////////////////

    private me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge mEdge;

    // Constructor /////////////////////////////////////////////////////////////

    HorizontalHandleHelper(me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge edge) {
        super(edge, null);
        mEdge = edge;
    }

    // HandleHelper Methods ////////////////////////////////////////////////////

    @Override
    void updateCropWindow(float x,
                          float y,
                          float targetAspectRatio,
                          Rect imageRect,
                          float snapRadius) {

        // Adjust this Edge accordingly.
        mEdge.adjustCoordinate(x, y, imageRect, snapRadius, targetAspectRatio);

        float left = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.LEFT.getCoordinate();
        float top = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.TOP.getCoordinate();
        float right = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.RIGHT.getCoordinate();
        float bottom = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.BOTTOM.getCoordinate();

        // After this Edge is moved, our crop window is now out of proportion.
        final float targetWidth = me.bobbleapp.sdk.faceselector.util.AspectRatioUtil.calculateWidth(top, bottom, targetAspectRatio);
        final float currentWidth = right - left;

        // Adjust the crop window so that it maintains the given aspect ratio by
        // moving the adjacent edges symmetrically in or out.
        final float difference = targetWidth - currentWidth;
        final float halfDifference = difference / 2;
        left -= halfDifference;
        right += halfDifference;

        me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.LEFT.setCoordinate(left);
        me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.RIGHT.setCoordinate(right);

        // Check if we have gone out of bounds on the sides, and fix.
        if (Edge.LEFT.isOutsideMargin(imageRect, snapRadius) && !mEdge.isNewRectangleOutOfBounds(Edge.LEFT,
                imageRect,
                targetAspectRatio)) {
            final float offset = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.LEFT.snapToRect(imageRect);
            me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.RIGHT.offset(-offset);
            mEdge.adjustCoordinate(targetAspectRatio);

        }
        if (Edge.RIGHT.isOutsideMargin(imageRect, snapRadius) && !mEdge.isNewRectangleOutOfBounds(Edge.RIGHT,
                imageRect,
                targetAspectRatio)) {
            final float offset = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.RIGHT.snapToRect(imageRect);
            me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.LEFT.offset(-offset);
            mEdge.adjustCoordinate(targetAspectRatio);
        }
    }
}
