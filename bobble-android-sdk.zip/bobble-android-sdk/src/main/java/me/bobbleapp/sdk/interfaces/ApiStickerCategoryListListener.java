package me.bobbleapp.sdk.interfaces;

import java.util.List;

import me.bobbleapp.sdk.model.ApiStickerCategory;

/**
 * Created by amitshekhar on 22/01/16.
 */
public interface ApiStickerCategoryListListener {
    void onSuccess(List<ApiStickerCategory> apiStickerCategoryList);

    void onError(String error);
}
