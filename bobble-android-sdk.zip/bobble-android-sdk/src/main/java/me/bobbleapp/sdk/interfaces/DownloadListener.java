package me.bobbleapp.sdk.interfaces;

/**
 * Created by amitshekhar on 16/01/16.
 */
public interface DownloadListener {

    void onDownloadComplete();

    void onError(String error);

}
