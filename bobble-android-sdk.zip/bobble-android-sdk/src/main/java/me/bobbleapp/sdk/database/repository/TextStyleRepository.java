package me.bobbleapp.sdk.database.repository;

import android.content.Context;

import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.TextStyle;
import me.bobbleapp.sdk.database.TextStyleDao;

public class TextStyleRepository {

    public static void insertOrUpdate(Context context, TextStyle textStyle) {
        getTextStyleDao(context).insertOrReplace(textStyle);
    }

    public static void clearTextStyles(Context context) {
        getTextStyleDao(context).deleteAll();
    }

    public static boolean isEmpty(Context context) {
        return (getTextStyleDao(context).count() == 0);
    }

    public static void deleteTextStyleWithId(Context context, long id) {
        getTextStyleDao(context).delete(getTextStyleForId(context, id));
    }

    public static List<TextStyle> getAllTextStyles(Context context) {
        return getTextStyleDao(context).loadAll();
    }

    public static TextStyle getTextStyleForId(Context context, long id) {
        return getTextStyleDao(context).load(id);
    }

    public static TextStyleDao getTextStyleDao(Context c) {
        return BobbleSDK.getDaoSession().getTextStyleDao();
    }
}
