package me.bobbleapp.sdk.networking;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.List;

import me.bobbleapp.sdk.interfaces.ApiStickerCategoryListListener;
import me.bobbleapp.sdk.interfaces.BobblificationListener;
import me.bobbleapp.sdk.interfaces.DownloadListener;
import me.bobbleapp.sdk.internal.BLog;
import me.bobbleapp.sdk.internal.BobbleDualImageDownloader;
import me.bobbleapp.sdk.internal.Constants;
import me.bobbleapp.sdk.model.ApiStickerCategory;
import me.bobbleapp.sdk.model.StickerCategoryData;

/**
 * Created by amitshekhar on 29/07/16.
 */
public final class SuccessHandlerUtil {

    public static void handleOnRegister(final Context context) {
        try {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
            sharedPreferences.edit().putBoolean(Constants.IS_USER_REGISTERED, true).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void handleConfigResponse(final Context context, final JSONObject jsonObject) {
        try {
            final SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
            sharedPreferences.edit().putInt(Constants.BOBBLE_TYPE, jsonObject.getInt("bobbleType")).apply();
            sharedPreferences.edit().putBoolean(Constants.ENABLE_SDK, jsonObject.getBoolean("enableSDK")).apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void handleStickerCategoryResponse(final List<ApiStickerCategory> apiStickerCategoryList, final ApiStickerCategoryListListener apiStickerCategoryListListener) {
        try {
            if (apiStickerCategoryList != null) {
                apiStickerCategoryListListener.onSuccess(apiStickerCategoryList);
            } else {
                apiStickerCategoryListListener.onError("onResponseError");
            }
        } catch (Exception e) {
            e.printStackTrace();
            apiStickerCategoryListListener.onError("onResponseException");
        }
    }

    public static void handleStickerCategoryData(final StickerCategoryData stickerCategoryData, final DownloadListener downloadListener) {
        try {
            if (stickerCategoryData != null) {
                Networking.downloadStickerCategoryZip(stickerCategoryData, downloadListener);
            } else {
                downloadListener.onError("onResponseError");
            }
        } catch (Exception e) {
            e.printStackTrace();
            downloadListener.onError("onResponseException");
        }
    }

    public static void handleBobblifyMaskBobbleResponse(final JSONObject jsonObject, final String path, final String gender, final BobblificationListener bobblificationListener) {
        try {
            if (jsonObject != null) {
                final String imageUrl = jsonObject.getString("bobblifiedImageFull");
                final String maskUrl = jsonObject.getString("masks");
                final int numOfMasks = jsonObject.getInt("numOfMasks");
                final JSONArray maskROIArray = new JSONArray(jsonObject.getString("maskROIs"));
                BLog.d("imageUrl :" + imageUrl);
                final JSONObject featurePoints = new JSONObject(jsonObject.getString("facialLandmarksOriginal")).getJSONObject("featurePoints");
                try {
                    File photo = new File(path);
                    if (photo.exists()) {
                        photo.delete();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                new BobbleDualImageDownloader(imageUrl, maskUrl, gender, numOfMasks, featurePoints, maskROIArray, bobblificationListener).download();
            } else {
                bobblificationListener.onError("errorOnResponse");
            }
        } catch (Exception e) {
            e.printStackTrace();
            bobblificationListener.onError("errorOnResponse");
        }
    }
}
