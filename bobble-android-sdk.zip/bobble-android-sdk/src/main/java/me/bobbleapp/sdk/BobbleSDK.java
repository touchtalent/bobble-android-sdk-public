package me.bobbleapp.sdk;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.preference.PreferenceManager;

import com.androidnetworking.AndroidNetworking;

import java.util.List;

import me.bobbleapp.sdk.database.BobbleHead;
import me.bobbleapp.sdk.database.BobbleHeadDao;
import me.bobbleapp.sdk.database.DaoMaster;
import me.bobbleapp.sdk.database.DaoSession;
import me.bobbleapp.sdk.database.Face;
import me.bobbleapp.sdk.database.Sticker;
import me.bobbleapp.sdk.database.StickerCategory;
import me.bobbleapp.sdk.database.StickerDao;
import me.bobbleapp.sdk.database.repository.BobbleHeadRepository;
import me.bobbleapp.sdk.database.repository.FaceRepository;
import me.bobbleapp.sdk.database.repository.StickerCategoryRepository;
import me.bobbleapp.sdk.database.repository.StickerRepository;
import me.bobbleapp.sdk.interfaces.ApiStickerCategoryListListener;
import me.bobbleapp.sdk.interfaces.BobblificationListener;
import me.bobbleapp.sdk.interfaces.DeleteListener;
import me.bobbleapp.sdk.interfaces.DownloadListener;
import me.bobbleapp.sdk.interfaces.FaceDetectionListener;
import me.bobbleapp.sdk.interfaces.SeedListener;
import me.bobbleapp.sdk.interfaces.StickerCreationListener;
import me.bobbleapp.sdk.internal.AndroidFaceDetector;
import me.bobbleapp.sdk.internal.BobbleException;
import me.bobbleapp.sdk.internal.BobbleImageHandler;
import me.bobbleapp.sdk.internal.BobbleSdkNotInitializedException;
import me.bobbleapp.sdk.internal.BobbleUtils;
import me.bobbleapp.sdk.internal.Constants;
import me.bobbleapp.sdk.internal.CreateStickerTask;
import me.bobbleapp.sdk.internal.SeedUtil;
import me.bobbleapp.sdk.networking.Networking;

/**
 * Created by amitshekhar on 25/07/16.
 */
public class BobbleSDK {

    public static final int REQUEST_CODE = 9005;
    public static final String FACE_ID = "faceId";
    private static Context applicationContext = null;
    private static boolean isSDKEnabled = false;
    private static DaoSession daoSession;
    public static String CLIENT_ID = "";

    private BobbleSDK() {

    }

    /**
     * initializer for BobbleSDK
     *
     * @param context  Context cannot be null
     * @param clientId token to authenticate and authorize your app with Bobble Server, this cannot be null or empty
     */
    public static void initialize(Context context, String clientId) {
        if (context == null) {
            throw new BobbleException("noContext", "Context cannot be null");
        } else if (clientId == null) {
            throw new BobbleException("noClientId", "clientId cannot be null");
        } else if (clientId.isEmpty()) {
            throw new BobbleException("emptyClientId", "clientId cannot be empty");
        }
        CLIENT_ID = clientId;
        applicationContext = context;
        AndroidNetworking.initialize(applicationContext);
        setupDatabase();
        Networking.getConfig(applicationContext);
        final SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext);
        isSDKEnabled = sharedPreferences.getBoolean(Constants.ENABLE_SDK, true);
        if (!sharedPreferences.getBoolean(Constants.IS_USER_REGISTERED, false)) {
            Networking.registerUser(applicationContext);
        }
    }

    /**
     * to get application context, this value should not be null
     */
    public static Context getContext() {
        if (applicationContext == null) {
            throw new BobbleSdkNotInitializedException("Initialize BobbleSDK : call BobbleSDK.initialize(context)");
        }
        return applicationContext;
    }

    private static void setupDatabase() {
        DaoMaster.DevOpenHelper helper = new DaoMaster.DevOpenHelper(getContext(), Constants.DATABASE_NAME, null);
        SQLiteDatabase db = helper.getWritableDatabase();
        DaoMaster daoMaster = new DaoMaster(db);
        daoSession = daoMaster.newSession();
    }

    public static DaoSession getDaoSession() {
        return daoSession;
    }

    public static boolean isContextAvailable() {
        return applicationContext != null;
    }

    /**
     * to test face detection: Single face, Multiple faces or No face
     *
     * @param bitmap                image
     * @param faceDetectionListener listener
     */
    public static void checkImage(Bitmap bitmap, final FaceDetectionListener faceDetectionListener) {
        if (!isReady()) {
            faceDetectionListener.onError("bobbleNotReady");
            return;
        } else if (!isSDKEnabled) {
            faceDetectionListener.onError("sdkNotEnabled");
            return;
        } else if (bitmap == null) {
            faceDetectionListener.onError("bitmapIsNull");
            return;
        }
        new AndroidFaceDetector(bitmap.copy(Bitmap.Config.RGB_565, false), new FaceDetectionListener() {
            @Override
            public void onSingleFaceDetection(RectF faceRectF) {
                faceDetectionListener.onSingleFaceDetection(faceRectF);
            }

            @Override
            public void onMultipleFaceDetection(List<RectF> facesRectFList) {
                faceDetectionListener.onMultipleFaceDetection(facesRectFList);
            }

            @Override
            public void onNoFaceDetection() {
                faceDetectionListener.onNoFaceDetection();
            }

            @Override
            public void onError(String error) {

            }
        });
    }

    /**
     * to test face detection: Single face, Multiple faces or No face
     *
     * @param path                  path of image
     * @param faceDetectionListener listener
     */
    public static void checkImage(String path, final FaceDetectionListener faceDetectionListener) {
        if (!isReady()) {
            faceDetectionListener.onError("bobbleNotReady");
            return;
        } else if (!isSDKEnabled) {
            faceDetectionListener.onError("sdkNotEnabled");
            return;
        } else if (path == null) {
            faceDetectionListener.onError("pathIsNull");
            return;
        }
        new AndroidFaceDetector(path, new FaceDetectionListener() {
            @Override
            public void onSingleFaceDetection(RectF faceRectF) {
                faceDetectionListener.onSingleFaceDetection(faceRectF);
            }

            @Override
            public void onMultipleFaceDetection(List<RectF> facesRectFList) {
                faceDetectionListener.onMultipleFaceDetection(facesRectFList);
            }

            @Override
            public void onNoFaceDetection() {
                faceDetectionListener.onNoFaceDetection();
            }

            @Override
            public void onError(String error) {

            }
        });
    }

    /**
     * method to create bobblified head
     *
     * @param path                   path of image, cannot be null
     * @param gender                 male or female, cannot be null
     * @param bobblificationListener listener
     */
    public static void bobblify(String path, String gender, BobblificationListener bobblificationListener) {
        if (!isReady()) {
            bobblificationListener.onError("bobbleNotReady");
            return;
        } else if (!isSDKEnabled) {
            bobblificationListener.onError("sdkNotEnabled");
            return;
        } else if (path == null) {
            bobblificationListener.onError("pathIsNull");
            return;
        } else if (gender == null) {
            bobblificationListener.onError("genderIsNull");
            return;
        } else if (!gender.equals("male") && !gender.equals("female")) {
            bobblificationListener.onError("genderIsNotValid");
            return;
        }
        new BobbleImageHandler(path, gender, bobblificationListener).execute();
    }

    /**
     * method to create bobblified head
     *
     * @param bitmap                 image, cannot be null
     * @param gender                 male or female, cannot be null
     * @param bobblificationListener listener
     */
    public static void bobblify(Bitmap bitmap, String gender, BobblificationListener bobblificationListener) {
        if (!isReady()) {
            bobblificationListener.onError("bobbleNotReady");
            return;
        } else if (!isSDKEnabled) {
            bobblificationListener.onError("sdkNotEnabled");
            return;
        } else if (bitmap == null) {
            bobblificationListener.onError("bitmapIsNull");
            return;
        } else if (gender == null) {
            bobblificationListener.onError("genderIsNull");
            return;
        } else if (!gender.equals("male") && !gender.equals("female")) {
            bobblificationListener.onError("genderIsNotValid");
            return;
        }
        new BobbleImageHandler(bitmap, gender, bobblificationListener).execute();
    }

    /**
     * method to create sticker
     *
     * @param bobbleHead bobblified head
     * @param sticker    selected sticker
     */
    public static void createSticker(final BobbleHead bobbleHead, final Sticker sticker, final StickerCreationListener stickerCreationListener) {
        if (!isSDKEnabled) {
            stickerCreationListener.onError("sdkNotEnabled");
            return;
        }
        new CreateStickerTask(bobbleHead, sticker, stickerCreationListener, null).execute();
    }

    /**
     * method to create On the fly sticker
     *
     * @param bobbleHead bobblified head
     * @param sticker    selected sticker
     * @param text       on the fly text
     */
    public static void createStickerOnTheFly(final BobbleHead bobbleHead, final Sticker sticker, String text, final StickerCreationListener stickerCreationListener) {
        if (!isSDKEnabled) {
            stickerCreationListener.onError("sdkNotEnabled");
            return;
        } else if (text == null) {
            stickerCreationListener.onError("textIsNull");
            return;
        }
        new CreateStickerTask(bobbleHead, sticker, stickerCreationListener, text).execute();
    }

    /**
     * to get all the faces for all bobblified heads, SDK must be enabled
     */
    public static List<Face> getAllFaces() {
        if (isSDKEnabled) {
            return FaceRepository.getAllFaces(BobbleSDK.getContext());
        } else {
            return null;
        }
    }

    /**
     * to get all bobble heads, SDK must be enabled
     */
    public static List<BobbleHead> getAllBobbleHead() {
        if (isSDKEnabled) {
            return BobbleHeadRepository.getAllBobbleHeads(BobbleSDK.getContext());
        } else {
            return null;
        }
    }

    /**
     * to get all bobblified heads for a particular faceId
     *
     * @param faceId unique id for each face
     */
    public static List<BobbleHead> getBobbleHeadForFaceId(final long faceId) {
        if (isSDKEnabled) {
            return BobbleHeadRepository.getAllBobbleHeadsForFaceId(BobbleSDK.getContext(), faceId);
        } else {
            return null;
        }
    }

    /**
     * to get preferred bobble head, priority set by server
     * SDK must be enabled and headList should not be null
     *
     * @param faceId faceId for which preferred bobble head is required
     */
    public static BobbleHead getPreferredBobbleHeadForFaceId(final long faceId) {
        List<BobbleHead> bobbleHeadList = BobbleHeadRepository.getBobbleHeadDao(BobbleSDK.getContext()).queryBuilder().where(BobbleHeadDao.Properties.FaceId.eq(faceId)).orderDesc(BobbleHeadDao.Properties.Priority).list();
        if (isSDKEnabled && bobbleHeadList != null && bobbleHeadList.size() != 0) {
            return bobbleHeadList.get(0);
        } else {
            return null;
        }
    }

    /**
     * to get all sticker categories(Packs)
     * SDK must be enabled
     */
    public static List<StickerCategory> getAllStickerCategory() {
        if (isSDKEnabled) {
            return StickerCategoryRepository.getAllStickerCategories(BobbleSDK.getContext());
        } else {
            return null;
        }
    }

    /**
     * to fetch all stickers for a particular sticker category
     *
     * @param stickerCategoryId unique id for each sticker category
     * @param bobbleHead        bobble head
     */
    public static List<Sticker> getStickerListForStickerCategoryId(final long stickerCategoryId, final BobbleHead bobbleHead) {
        if (!isSDKEnabled || bobbleHead == null || bobbleHead.getFace() == null || bobbleHead.getFace().getGender() == null) {
            return null;
        }
        return StickerRepository.getStickerDao(BobbleSDK.getContext()).queryBuilder().where(StickerDao.Properties.StickerCategoryId.eq(stickerCategoryId)).where(StickerDao.Properties.Gender.notEq(bobbleHead.getFace().getGender().equals("male") ? "female" : "male")).orderDesc(StickerDao.Properties.Priority).list();
    }

    /**
     * to fetch all stickers
     *
     * @param bobbleHead bobble head
     */
    public static List<Sticker> getStickerList(final BobbleHead bobbleHead) {
        if (!isSDKEnabled || bobbleHead == null || bobbleHead.getFace() == null || bobbleHead.getFace().getGender() == null) {
            return null;
        }
        return StickerRepository.getStickerDao(BobbleSDK.getContext()).queryBuilder().where(StickerDao.Properties.Gender.notEq(bobbleHead.getFace().getGender().equals("male") ? "female" : "male")).orderDesc(StickerDao.Properties.Priority).list();
    }

    /**
     * to get page wise sticker categories list
     *
     * @param limit                          numeric value to set limit, this should not be changed in a session
     * @param page                           to set no. of pages
     * @param apiStickerCategoryListListener listener
     */
    public static void getApiStickerCategoryList(int limit, int page, final ApiStickerCategoryListListener apiStickerCategoryListListener) {
        Networking.getStickerCategory(limit, page, apiStickerCategoryListListener);
    }

    /**
     * to download sticker category(pack)
     *
     * @param id               unique id to download sticker category
     * @param downloadListener listener
     */
    public static void downloadStickerCategoryForId(long id, final DownloadListener downloadListener) {
        Networking.getStickerCategoryDataForId(id, downloadListener);
    }

    /**
     * to delete a sticker category
     *
     * @param stickerCategoryId sticker category id for deletion
     * @param deleteListener    listener
     */
    public static void deleteStickerCategory(long stickerCategoryId, final DeleteListener deleteListener) {
        BobbleUtils.delete(Constants.STICKER_CATEGORY, stickerCategoryId, deleteListener);
    }

    /**
     * to delete a sticker
     *
     * @param stickerId      sticker id for deletion
     * @param deleteListener listener
     */
    public static void deleteSticker(long stickerId, final DeleteListener deleteListener) {
        BobbleUtils.delete(Constants.STICKER, stickerId, deleteListener);
    }

    /**
     * to delete a face
     *
     * @param faceId         face id for deletion
     * @param deleteListener listener
     */
    public static void deleteFace(long faceId, final DeleteListener deleteListener) {
        BobbleUtils.delete(Constants.FACE, faceId, deleteListener);
    }

    /**
     * to delete a bobbleHead
     *
     * @param bobbleHeadId   bobbleHead id for deletion
     * @param deleteListener listener
     */
    public static void deleteBobbleHead(long bobbleHeadId, final DeleteListener deleteListener) {
        BobbleUtils.delete(Constants.BOBBLE_HEAD, bobbleHeadId, deleteListener);
    }

    /**
     * to seed stickers or sticker category
     *
     * @param rawResId     raw resource id of zip file
     * @param seedListener listener
     */
    public static void seed(int rawResId, final SeedListener seedListener) {
        SeedUtil.seed(getContext(), rawResId, null, seedListener);
    }

    /**
     * to seed stickers or sticker category
     *
     * @param zipPath      path of zip file
     * @param seedListener listener
     */
    public static void seed(String zipPath, final SeedListener seedListener) {
        SeedUtil.seed(getContext(), 0, zipPath, seedListener);
    }

    /**
     * to check if bobble sdk is ready or not
     */
    public static boolean isReady() {
        return isSDKEnabled;
    }

    public static void cancelBobblification() {
        AndroidNetworking.cancel(Constants.BOBBLIFICATION);
    }

    /**
     * to close bobble instance
     */
    public static void shutDown() {
        AndroidNetworking.shutDown();
        applicationContext = null;
    }

}
