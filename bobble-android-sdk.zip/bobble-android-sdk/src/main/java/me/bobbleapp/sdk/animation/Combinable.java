package me.bobbleapp.sdk.animation;

import android.animation.AnimatorSet;
import android.animation.TimeInterpolator;

/**
 * Created by amitshekhar on 01/08/15.
 */
public interface Combinable {

    public void animate();
    public AnimatorSet getAnimatorSet();
    public Animation setInterpolator(TimeInterpolator interpolator);
    public long getDuration();
    public Animation setDuration(long duration);
    public Animation setListener(AnimationListener listener);
}
