package me.bobbleapp.sdk.model;

/**
 * Created by amitshekhar on 22/01/16.
 */
public class ApiSticker {
    private long stickerId;
    private String stickerGender;
    private int stickerPriority;
    private String stickerBackgroundColor;
    private String stickerLayerOrders;
    private long stickerCategory;
    private long stickerBackground;
    private long stickerCharacter;
    private long stickerText;
    private long stickerTextStyle;

    public long getStickerId() {
        return stickerId;
    }

    public void setStickerId(long stickerId) {
        this.stickerId = stickerId;
    }

    public String getStickerGender() {
        return stickerGender;
    }

    public void setStickerGender(String stickerGender) {
        this.stickerGender = stickerGender;
    }

    public int getStickerPriority() {
        return stickerPriority;
    }

    public void setStickerPriority(int stickerPriority) {
        this.stickerPriority = stickerPriority;
    }

    public String getStickerBackgroundColor() {
        return stickerBackgroundColor;
    }

    public void setStickerBackgroundColor(String stickerBackgroundColor) {
        this.stickerBackgroundColor = stickerBackgroundColor;
    }

    public String getStickerLayerOrders() {
        return stickerLayerOrders;
    }

    public void setStickerLayerOrders(String stickerLayerOrders) {
        this.stickerLayerOrders = stickerLayerOrders;
    }

    public long getStickerCategory() {
        return stickerCategory;
    }

    public void setStickerCategory(long stickerCategory) {
        this.stickerCategory = stickerCategory;
    }

    public long getStickerBackground() {
        return stickerBackground;
    }

    public void setStickerBackground(long stickerBackground) {
        this.stickerBackground = stickerBackground;
    }

    public long getStickerCharacter() {
        return stickerCharacter;
    }

    public void setStickerCharacter(long stickerCharacter) {
        this.stickerCharacter = stickerCharacter;
    }

    public long getStickerText() {
        return stickerText;
    }

    public void setStickerText(long stickerText) {
        this.stickerText = stickerText;
    }

    public long getStickerTextStyle() {
        return stickerTextStyle;
    }

    public void setStickerTextStyle(long stickerTextStyle) {
        this.stickerTextStyle = stickerTextStyle;
    }
}
