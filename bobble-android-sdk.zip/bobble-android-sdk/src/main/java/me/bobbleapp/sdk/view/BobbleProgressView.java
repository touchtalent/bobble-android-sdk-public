package me.bobbleapp.sdk.view;

import android.graphics.Bitmap;

/**
 * Created by Prashant Gupta on 29-07-2016.
 */
public interface BobbleProgressView extends BaseView {

    void bobbleCompletion(long faceId, Bitmap bobble);

    void bobbleError(String error);

    void onFinish();

}
