package me.bobbleapp.sdk.internal;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Build;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.BobbleHead;
import me.bobbleapp.sdk.database.Font;
import me.bobbleapp.sdk.database.repository.BobbleHeadRepository;
import me.bobbleapp.sdk.database.repository.FaceRepository;
import me.bobbleapp.sdk.database.repository.FontRepository;
import me.bobbleapp.sdk.database.repository.StickerCategoryRepository;
import me.bobbleapp.sdk.database.repository.StickerRepository;
import me.bobbleapp.sdk.interfaces.DeleteListener;

/**
 * Created by amitshekhar on 13/01/16.
 */
public class BobbleUtils {

    public static Bitmap decodeSampledBitmapFromFile(String picturePath, int width, int height) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(picturePath, options);
        options.inSampleSize = calculateInSampleSize(options, width, height);
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(picturePath, options);
    }

    private static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            while ((halfHeight / inSampleSize) > reqHeight
                    || (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }
        return inSampleSize;
    }

    public static String getDeviceId(Context context) {
        String androidDeviceId = getAndroidDeviceId(context);
        if (androidDeviceId == null)
            androidDeviceId = UUID.randomUUID().toString();
        return androidDeviceId;

    }

    private static String getAndroidDeviceId(Context context) {
        final String INVALID_ANDROID_ID = "9774d56d682e549c";
        final String androidId = android.provider.Settings.Secure.getString(
                context.getContentResolver(),
                android.provider.Settings.Secure.ANDROID_ID);
        if (androidId == null
                || androidId.toLowerCase().equals(INVALID_ANDROID_ID)) {
            return null;
        }
        return androidId;
    }

    public static String getTimeZone() {
        TimeZone tz = TimeZone.getDefault();
        return tz.getID();
    }

    public static String getLanguage() {
        return Locale.getDefault().toString();
    }

    public static String saveImageTemporarily(Bitmap bitmap) {
        try {
            File file = File.createTempFile("bobble", ".png", BobbleSDK.getContext().getCacheDir());
            file.createNewFile();
            FileOutputStream fos = new FileOutputStream(file.getAbsolutePath());
            bitmap.compress(Bitmap.CompressFormat.PNG, 0 /* ignored for PNG */, fos);
            fos.flush();
            fos.close();
            return file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getDeviceInfo() {
        String mfg = "unknown";
        try {
            final Class<?> buildClass = Build.class;
            mfg = (String) buildClass.getField("MANUFACTURER").get(null);
            mfg = mfg + " " + buildClass.getField("MODEL").get(null);
            mfg = mfg + " " + buildClass.getField("PRODUCT").get(null);
        } catch (final Exception ignore) {

        }

        HashMap<String, String> params = new HashMap<String, String>();
        try {
            params.put("ModelInfo", mfg);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return params.toString();
    }

    public static Bitmap getLocalImage(Context context, String value) throws OutOfMemoryError {
        Bitmap image = null;
        if (value == null)
            return null;

        if (value.startsWith("/")) {
            image = BitmapFactory.decodeFile(value);
        } else {
            int resDrawable = context.getResources().getIdentifier(value,
                    "drawable", "me.bobbleapp.sdk");
            image = BitmapFactory.decodeResource(context.getResources(), resDrawable);
        }
        return image;
    }

    public static Typeface getTypeface(Context context, Long fontId) {
        Font font = FontRepository.getFontForId(context, fontId);
        if (font == null) {
            return Typeface.DEFAULT;
        }
        String value = font.getLocalPath();
        Typeface tf = null;
        if (value == null) {
            tf = Typeface.DEFAULT;
        } else {
            if (value.startsWith("/")) {
                tf = Typeface.createFromFile(value);
            } else {
                tf = Typefaces.get(context, value);
            }
        }
        return tf;
    }

    public static Bitmap applyShadow(Bitmap bitmap, String color, float radius, int dx, int dy, BlurMaskFilter.Blur blur) {
        if (radius == 0)
            return bitmap;

        int borderWidth = (int) radius;
        Bitmap sbitmap = Bitmap.createBitmap(bitmap.getWidth() + borderWidth, bitmap.getHeight() + borderWidth, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(sbitmap);
        BlurMaskFilter blurMaskFilter = new BlurMaskFilter(radius, blur);
        Paint shadowPaint = new Paint();
        shadowPaint.setMaskFilter(blurMaskFilter);
        Bitmap shadowBitmap = bitmap.extractAlpha(shadowPaint, null);
        shadowPaint.setColor(Color.parseColor(color));
        c.drawBitmap(shadowBitmap, dx, dy, shadowPaint);
        Paint paint = new Paint();
        c.drawBitmap(bitmap, borderWidth, borderWidth, paint);
        Bitmap rbitmap = Bitmap.createBitmap(sbitmap, borderWidth, borderWidth, bitmap.getWidth(), bitmap.getHeight());
        shadowBitmap.recycle();
        sbitmap.recycle();
        return rbitmap;
    }

    public static void delete(final String type, final Long id, final DeleteListener deleteListener) {
        if (type == null || id == null) {
            if (deleteListener != null) {
                deleteListener.onError("errorWhileDeletion");
            }
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                switch (type) {
                    case Constants.STICKER_CATEGORY:
                        try {
                            final String folderPath = BobbleSDK.getContext().getExternalFilesDir(null) + File.separator + "stickerPack" + File.separator + "sticker_category_" + id;
                            FileUtil.delete(folderPath);
                            StickerCategoryRepository.deleteStickerCategoryWithId(BobbleSDK.getContext(), id);
                            if (deleteListener != null) {
                                deleteListener.onDeleteCompletion();
                            }
                        } catch (Exception e) {
                            if (deleteListener != null) {
                                deleteListener.onError("errorWhileDeletion");
                            }
                        }
                        break;
                    case Constants.STICKER:
                        try {
                            StickerRepository.deleteStickerWithId(BobbleSDK.getContext(), id);
                            if (deleteListener != null) {
                                deleteListener.onDeleteCompletion();
                            }
                        } catch (Exception e) {
                            if (deleteListener != null) {
                                deleteListener.onError("errorWhileDeletion");
                            }
                        }
                        break;
                    case Constants.BOBBLE_HEAD:
                        try {
                            BobbleHead bobbleHead = BobbleHeadRepository.getBobbleHeadForId(BobbleSDK.getContext(), id);
                            FileUtil.delete(bobbleHead.getLocalImage());
                            BobbleHeadRepository.deleteBobbleHeadWithId(BobbleSDK.getContext(), id);
                            if (deleteListener != null) {
                                deleteListener.onDeleteCompletion();
                            }
                        } catch (Exception e) {
                            if (deleteListener != null) {
                                deleteListener.onError("errorWhileDeletion");
                            }
                        }
                        break;
                    case Constants.FACE:
                        try {
                            List<BobbleHead> bobbleHeadList = BobbleHeadRepository.getAllBobbleHeadsForFaceId(BobbleSDK.getContext(), id);
                            for (BobbleHead bobbleHead : bobbleHeadList) {
                                FileUtil.delete(bobbleHead.getLocalImage());
                                BobbleHeadRepository.deleteBobbleHeadWithId(BobbleSDK.getContext(), bobbleHead.getId());
                            }
                            FaceRepository.deleteFaceWithId(BobbleSDK.getContext(), id);
                            if (deleteListener != null) {
                                deleteListener.onDeleteCompletion();
                            }
                        } catch (Exception e) {
                            if (deleteListener != null) {
                                deleteListener.onError("errorWhileDeletion");
                            }
                        }
                        break;
                }
            }
        }).start();
    }

    public static String getDirPath() {
        return BobbleSDK.getContext().getExternalFilesDir(null).getAbsolutePath();
    }

    public static String getUniqueFileName(String type, String extension) {
        return type + System.currentTimeMillis() + extension;
    }

    public static void saveImage(Bitmap bitmap, String path) {
        BLog.d("saveImage");
        File photo = new File(path);
        try {
            photo.createNewFile();
            FileOutputStream fos = new FileOutputStream(photo.getAbsolutePath());
            bitmap.compress(Bitmap.CompressFormat.PNG, 0 /* ignored for PNG */, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static int dpToPx(int dp, Context context) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dp * scale + 0.5f);
    }

}
