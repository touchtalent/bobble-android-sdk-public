package me.bobbleapp.sdk.view.fragment;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import me.bobbleapp.sdk.R;
import me.bobbleapp.sdk.interfaces.FragmentCallback;
import me.bobbleapp.sdk.internal.BLog;
import me.bobbleapp.sdk.internal.CircularImageView;
import me.bobbleapp.sdk.internal.Constants;
import me.bobbleapp.sdk.presenter.BobbleProgressPresenter;
import me.bobbleapp.sdk.view.BobbleProgressView;

/**
 * Created by Prashant Gupta on 29-07-2016.
 */
public class BobbleProgressFragment extends Fragment implements BobbleProgressView, View.OnClickListener {

    private static final String TAG = BobbleProgressFragment.class.getSimpleName();
    private String gender;
    private long faceId;
    private BobbleProgressPresenter presenter;
    private FragmentCallback fragmentCallback;
    private CircularImageView circularImageView;
    private ProgressBar circularProgressBar;
    private TextView header, dintLike, retakePhoto;
    private ImageView actionBarDone;
    private ImageView bobbleImageView;

    @Override
    public Context context() {
        return getActivity().getApplicationContext();
    }

    @Override
    public void onAttach(Context context) {
        BLog.d(TAG, "onAttach");
        super.onAttach(context);
        try {
            fragmentCallback = (FragmentCallback) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement FragmentCallback");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        BLog.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        presenter = new BobbleProgressPresenter();
        gender = getArguments().getString("gender");
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        BLog.d(TAG, "onCreateView");
        View view = inflater.inflate(R.layout.fragment_bobble_progress, container, false);
        initializeView(view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        BLog.d(TAG, "onViewCreated");
        super.onViewCreated(view, savedInstanceState);
        presenter.setView(this);
        presenter.bobblify(fragmentCallback.getInputBitmap(), gender);
    }

    @Override
    public void onStart() {
        BLog.d(TAG, "onStart");
        super.onStart();
        presenter.start();
    }

    @Override
    public void onResume() {
        BLog.d(TAG, "onResume");
        super.onResume();
        presenter.resume();
    }

    @Override
    public void onDestroyView() {
        BLog.d(TAG, "onDestroyView");
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        BLog.d(TAG, "onDestroy");
        super.onDestroy();
        presenter.destroy();
        presenter = null;
    }

    @Override
    public void onPause() {
        BLog.d(TAG, "onPause");
        super.onPause();
        presenter.pause();
    }

    @Override
    public void onStop() {
        BLog.d(TAG, "onStop");
        super.onStop();
        presenter.stop();
    }

    private void initializeView(View view) {
        circularImageView = (CircularImageView) view.findViewById(R.id.circularImageView);
        circularProgressBar = (ProgressBar) view.findViewById(R.id.circularProgressBar);
        header = (TextView) view.findViewById(R.id.tv_header);
        actionBarDone = (ImageView) view.findViewById(R.id.ivManage);
        bobbleImageView = (ImageView) view.findViewById(R.id.bobbleImageView);
        dintLike = (TextView) view.findViewById(R.id.dintLike);
        retakePhoto = (TextView) view.findViewById(R.id.retakePhoto);
        header.setText(getActivity().getApplicationContext().getString(R.string.processing));
        circularImageView.setImageBitmap(fragmentCallback.getInputBitmap());
    }

    public void deleteFace() {
        if (presenter != null) {
            presenter.deleteFace(faceId);
        }
    }

    public void cancelBobblification() {
        if (presenter != null) {
            presenter.cancelBobblification();
        }
    }

    private void retry() {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.popBackStack(Constants.IMAGE_PICKER_BACK_STACK, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }

    @Override
    public void bobbleCompletion(long faceId, Bitmap bobble) {
        try {
            circularImageView.setVisibility(View.GONE);
            circularProgressBar.setVisibility(View.GONE);
            bobbleImageView.setVisibility(View.VISIBLE);
            bobbleImageView.setImageBitmap(bobble);
            header.setText(getActivity().getApplicationContext().getString(R.string.bobble_output));
            actionBarDone.setVisibility(View.VISIBLE);
            actionBarDone.setImageResource(R.drawable.ic_bobble_next);
            actionBarDone.setOnClickListener(BobbleProgressFragment.this);
            BobbleProgressFragment.this.faceId = faceId;
            dintLike.setVisibility(View.VISIBLE);
            retakePhoto.setVisibility(View.VISIBLE);
            retakePhoto.setOnClickListener(this);
            retakePhoto.setPaintFlags(retakePhoto.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View view) {
        final int id = view.getId();
        if (id == R.id.ivManage) {
            BLog.d(TAG, "buttonDone clicked");
            presenter.onFinish();
        } else if (id == R.id.retakePhoto) {
            BLog.d(TAG, "buttonRetake clicked");
            deleteFace();
            retry();
        }
    }

    @Override
    public void bobbleError(String error) {
        try {
            switch (error) {
                case Constants.NO_FACE_DETECTED_ERROR:
                    circularProgressBar.setVisibility(View.GONE);
                    header.setText(getActivity().getApplicationContext().getString(R.string.no_face_detected));
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle(R.string.no_face_detected);
                    builder.setMessage(getString(R.string.no_face_detected_dialog));
                    builder.setCancelable(false);
                    builder.setNegativeButton(R.string.retake, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.dismiss();
                            retry();
                        }
                    });
                    try {
                        builder.show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                case Constants.CONNECTION_ERROR: {
                    Toast.makeText(getActivity().getApplicationContext(), getActivity().getApplicationContext().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    fragmentManager.popBackStack();
                    break;
                }
                default: {
                    Toast.makeText(getActivity().getApplicationContext(), getActivity().getApplicationContext().getString(R.string.some_error_occurred), Toast.LENGTH_SHORT).show();
                    FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                    fragmentManager.popBackStack();
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onFinish() {
        fragmentCallback.finishBobbleCreationProcess(faceId);
    }

}
