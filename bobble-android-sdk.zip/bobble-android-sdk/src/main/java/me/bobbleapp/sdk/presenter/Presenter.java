package me.bobbleapp.sdk.presenter;

/**
 * Created by amitshekhar on 25/07/16.
 */
public interface Presenter {

    void resume();

    void pause();

    void destroy();

    void stop();

    void start();
}