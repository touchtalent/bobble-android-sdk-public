package me.bobbleapp.sdk.internal;

import android.graphics.Bitmap;
import android.graphics.PointF;
import android.graphics.RectF;
import android.media.FaceDetector;
import android.os.AsyncTask;

import java.util.ArrayList;
import java.util.List;

import me.bobbleapp.sdk.interfaces.FaceDetectionListener;

/**
 * Created by Prashant Gupta on 28-07-2016.
 */
public class AndroidFaceDetector {

    private int numberOfFaceDetected = 0;
    private static final int MAX_NUM_OF_FACES = 3;
    private FaceDetector faceDetector;
    private FaceDetector.Face[] faces;
    private String mPath;
    private final List<RectF> rectFList = new ArrayList<RectF>();
    private Bitmap mBitmap;
    private final FaceDetectionListener mFaceDetectionListener;

    public AndroidFaceDetector(Bitmap bitmap, int maxNumberOfFace) {
        faces = new FaceDetector.Face[maxNumberOfFace];
        faceDetector = new FaceDetector(bitmap.getWidth(), bitmap.getHeight(), maxNumberOfFace);
        numberOfFaceDetected = faceDetector.findFaces(bitmap, faces);
        this.mFaceDetectionListener = null;
    }

    public AndroidFaceDetector(Bitmap bitmap, FaceDetectionListener faceDetectionListener) {
        this.mFaceDetectionListener = faceDetectionListener;
        this.mBitmap = bitmap;
        new DetectFaces().execute();
    }

    public AndroidFaceDetector(String path, FaceDetectionListener faceDetectionListener) {
        this.mFaceDetectionListener = faceDetectionListener;
        this.mPath = path;
        new DetectFaces().execute();
    }

    public FaceDetector.Face[] getFaces() {
        return faces;
    }

    public void setFaces(FaceDetector.Face[] faces) {
        this.faces = faces;
    }

    public int getNumberOfFaceDetected() {
        return numberOfFaceDetected;
    }

    public void setNumberOfFaceDetected(int numberOfFaceDetected) {
        this.numberOfFaceDetected = numberOfFaceDetected;
    }

    private class DetectFaces extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            float scaleFactor = 1;
            if (mBitmap == null) {
                mBitmap = BobbleUtils.decodeSampledBitmapFromFile(mPath, 400, 400).copy(Bitmap.Config.RGB_565, false);
                final double ratio = (double) mBitmap.getHeight() / mBitmap.getWidth();
                int width = (int) (400 / ratio);
                if (width % 2 == 1) width = width - 1;
                final int initialHeight = mBitmap.getHeight();
                mBitmap = Bitmap.createScaledBitmap(mBitmap, width, 400, true);
                scaleFactor = initialHeight / mBitmap.getHeight();
            } else {
                final double ratio = (double) mBitmap.getHeight() / mBitmap.getWidth();
                final int width = (int) (400 / ratio);
                final int initialHeight = mBitmap.getHeight();
                mBitmap = Bitmap.createScaledBitmap(mBitmap, width, 400, true);
                scaleFactor = initialHeight / mBitmap.getHeight();
            }
            faces = new FaceDetector.Face[MAX_NUM_OF_FACES];
            FaceDetector faceDetector = new FaceDetector(mBitmap.getWidth(), mBitmap.getHeight(), MAX_NUM_OF_FACES);
            numberOfFaceDetected = faceDetector.findFaces(mBitmap, faces);
            for (int i = 0; i < numberOfFaceDetected; i++) {
                final float maxEyeDistance = faces[i].eyesDistance();
                final PointF midPoint = new PointF();
                faces[i].getMidPoint(midPoint);
                RectF rectF = new RectF((midPoint.x - maxEyeDistance * 2) * scaleFactor, (midPoint.y - maxEyeDistance * 2) * scaleFactor, (midPoint.x + maxEyeDistance * 2) * scaleFactor, (midPoint.y + maxEyeDistance * 2) * scaleFactor);  //left top right bottom
                rectFList.add(rectF);
            }
            if (mBitmap != null && !mBitmap.isRecycled()) {
                mBitmap.recycle();
                mBitmap = null;
            }
            return null;
        }


        @Override
        protected void onPostExecute(Void aVoid) {
            if (rectFList != null && rectFList.size() > 1) {
                mFaceDetectionListener.onMultipleFaceDetection(rectFList);
            } else if (rectFList != null && rectFList.size() == 1) {
                mFaceDetectionListener.onSingleFaceDetection(rectFList.get(0));
            } else if (rectFList != null && rectFList.size() == 0) {
                mFaceDetectionListener.onNoFaceDetection();
            }
        }
    }

}
