package me.bobbleapp.sdk.model;

import java.util.List;

/**
 * Created by amitshekhar on 22/01/16.
 */
public class ApiStickerCategory {

    private long stickerCategoryId;
    private String stickerCategoryName;
    private String stickerCategoryDescription;
    private String stickerCategoryImage;
    private String stickerCategoryBannerImageHDPI;
    private String stickerCategoryBannerImageXHDPI;
    private String stickerCategoryBannerImageXXHDPI;
    private String fileSizeHDPI;
    private String fileSizeXHDPI;
    private String stickerCategoryPreviewImageUrl;
    private String stickerCategoryImageHDPI;
    private String stickerCategoryImageXHDPI;
    private String stickerCategoryImageXXHDPI;
    private int numberStickers;
    List<String> stickerCategoryPreviewImages;

    public long getStickerCategoryId() {
        return stickerCategoryId;
    }

    public void setStickerCategoryId(long stickerCategoryId) {
        this.stickerCategoryId = stickerCategoryId;
    }

    public String getStickerCategoryName() {
        return stickerCategoryName;
    }

    public void setStickerCategoryName(String stickerCategoryName) {
        this.stickerCategoryName = stickerCategoryName;
    }

    public String getStickerCategoryDescription() {
        return stickerCategoryDescription;
    }

    public void setStickerCategoryDescription(String stickerCategoryDescription) {
        this.stickerCategoryDescription = stickerCategoryDescription;
    }

    public String getStickerCategoryImage() {
        return stickerCategoryImage;
    }

    public void setStickerCategoryImage(String stickerCategoryImage) {
        this.stickerCategoryImage = stickerCategoryImage;
    }

    public String getStickerCategoryBannerImageHDPI() {
        return stickerCategoryBannerImageHDPI;
    }

    public void setStickerCategoryBannerImageHDPI(String stickerCategoryBannerImageHDPI) {
        this.stickerCategoryBannerImageHDPI = stickerCategoryBannerImageHDPI;
    }

    public String getStickerCategoryBannerImageXHDPI() {
        return stickerCategoryBannerImageXHDPI;
    }

    public void setStickerCategoryBannerImageXHDPI(String stickerCategoryBannerImageXHDPI) {
        this.stickerCategoryBannerImageXHDPI = stickerCategoryBannerImageXHDPI;
    }

    public String getStickerCategoryBannerImageXXHDPI() {
        return stickerCategoryBannerImageXXHDPI;
    }

    public void setStickerCategoryBannerImageXXHDPI(String stickerCategoryBannerImageXXHDPI) {
        this.stickerCategoryBannerImageXXHDPI = stickerCategoryBannerImageXXHDPI;
    }

    public String getFileSizeHDPI() {
        return fileSizeHDPI;
    }

    public void setFileSizeHDPI(String fileSizeHDPI) {
        this.fileSizeHDPI = fileSizeHDPI;
    }

    public String getFileSizeXHDPI() {
        return fileSizeXHDPI;
    }

    public void setFileSizeXHDPI(String fileSizeXHDPI) {
        this.fileSizeXHDPI = fileSizeXHDPI;
    }

    public String getStickerCategoryPreviewImageUrl() {
        return stickerCategoryPreviewImageUrl;
    }

    public void setStickerCategoryPreviewImageUrl(String stickerCategoryPreviewImageUrl) {
        this.stickerCategoryPreviewImageUrl = stickerCategoryPreviewImageUrl;
    }

    public String getStickerCategoryImageHDPI() {
        return stickerCategoryImageHDPI;
    }

    public void setStickerCategoryImageHDPI(String stickerCategoryImageHDPI) {
        this.stickerCategoryImageHDPI = stickerCategoryImageHDPI;
    }

    public String getStickerCategoryImageXHDPI() {
        return stickerCategoryImageXHDPI;
    }

    public void setStickerCategoryImageXHDPI(String stickerCategoryImageXHDPI) {
        this.stickerCategoryImageXHDPI = stickerCategoryImageXHDPI;
    }

    public String getStickerCategoryImageXXHDPI() {
        return stickerCategoryImageXXHDPI;
    }

    public void setStickerCategoryImageXXHDPI(String stickerCategoryImageXXHDPI) {
        this.stickerCategoryImageXXHDPI = stickerCategoryImageXXHDPI;
    }

    public int getNumberStickers() {
        return numberStickers;
    }

    public void setNumberStickers(int numberStickers) {
        this.numberStickers = numberStickers;
    }

    public List<String> getStickerCategoryPreviewImages() {
        return stickerCategoryPreviewImages;
    }

    public void setStickerCategoryPreviewImages(List<String> stickerCategoryPreviewImages) {
        this.stickerCategoryPreviewImages = stickerCategoryPreviewImages;
    }
}
