package me.bobbleapp.sdk.model;

/**
 * Created by amitshekhar on 22/01/16.
 */
public class ApiStickerBackground {

    private long stickerBackgroundId;
    private String stickerBackgroundImageHDPI;
    private String stickerBackgroundImageXHDPI;
    private String stickerBackgroundImageXXHDPI;
    private String stickerBackgroundImage;

    public long getStickerBackgroundId() {
        return stickerBackgroundId;
    }

    public void setStickerBackgroundId(long stickerBackgroundId) {
        this.stickerBackgroundId = stickerBackgroundId;
    }

    public String getStickerBackgroundImageHDPI() {
        return stickerBackgroundImageHDPI;
    }

    public void setStickerBackgroundImageHDPI(String stickerBackgroundImageHDPI) {
        this.stickerBackgroundImageHDPI = stickerBackgroundImageHDPI;
    }

    public String getStickerBackgroundImageXHDPI() {
        return stickerBackgroundImageXHDPI;
    }

    public void setStickerBackgroundImageXHDPI(String stickerBackgroundImageXHDPI) {
        this.stickerBackgroundImageXHDPI = stickerBackgroundImageXHDPI;
    }

    public String getStickerBackgroundImageXXHDPI() {
        return stickerBackgroundImageXXHDPI;
    }

    public void setStickerBackgroundImageXXHDPI(String stickerBackgroundImageXXHDPI) {
        this.stickerBackgroundImageXXHDPI = stickerBackgroundImageXXHDPI;
    }

    public String getStickerBackgroundImage() {
        return stickerBackgroundImage;
    }

    public void setStickerBackgroundImage(String stickerBackgroundImage) {
        this.stickerBackgroundImage = stickerBackgroundImage;
    }
}
