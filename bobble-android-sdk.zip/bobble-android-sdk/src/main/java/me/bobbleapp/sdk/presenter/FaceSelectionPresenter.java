package me.bobbleapp.sdk.presenter;

import android.graphics.Bitmap;
import android.graphics.Matrix;

import me.bobbleapp.sdk.internal.AndroidFaceDetector;
import me.bobbleapp.sdk.view.FaceSelectionView;

/**
 * Created by amitshekhar on 27/07/16.
 */
public class FaceSelectionPresenter implements Presenter {

    private FaceSelectionView faceSelectionView;

    public FaceSelectionPresenter() {

    }

    public void setView(FaceSelectionView faceSelectionView) {
        this.faceSelectionView = faceSelectionView;
    }

    public void onNext() {
        this.faceSelectionView.navigate();
    }

    public void onFaceDetection(AndroidFaceDetector androidFaceDetector) {
        if (androidFaceDetector != null) {
            if (androidFaceDetector.getNumberOfFaceDetected() == 0) {
                this.faceSelectionView.noFaceDetection();
            } else if (androidFaceDetector.getNumberOfFaceDetected() == 1) {
                this.faceSelectionView.singleFaceDetection();
            } else {
                this.faceSelectionView.multipleFaceDetection();
            }
        }
    }

    public void onRotateImage(Bitmap bitmap) {
        try {
            Matrix matrix = new Matrix();
            matrix.postRotate(90);
            bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
            this.faceSelectionView.rotate(bitmap);
        } catch (Exception e) {
            this.faceSelectionView.onRotateError();
        }
    }

    @Override
    public void resume() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void destroy() {
        this.faceSelectionView = null;
    }

    @Override
    public void stop() {

    }

    @Override
    public void start() {

    }
}
