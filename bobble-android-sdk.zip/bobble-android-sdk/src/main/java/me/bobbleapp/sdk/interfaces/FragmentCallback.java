package me.bobbleapp.sdk.interfaces;

import android.graphics.Bitmap;

/**
 * Created by amitshekhar on 01/08/16.
 */
public interface FragmentCallback {

    Bitmap getInputBitmap();

    void setInputBitmap(Bitmap bitmap);

    void finishBobbleCreationProcess(long faceId);

    void releaseInputBitmap();

}
