package me.bobbleapp.sdk.internal;

import android.os.AsyncTask;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.Font;
import me.bobbleapp.sdk.database.Sticker;
import me.bobbleapp.sdk.database.StickerBackground;
import me.bobbleapp.sdk.database.StickerCategory;
import me.bobbleapp.sdk.database.StickerCharacter;
import me.bobbleapp.sdk.database.StickerText;
import me.bobbleapp.sdk.database.TextStyle;
import me.bobbleapp.sdk.database.repository.FontRepository;
import me.bobbleapp.sdk.database.repository.StickerBackgroundRepository;
import me.bobbleapp.sdk.database.repository.StickerCategoryRepository;
import me.bobbleapp.sdk.database.repository.StickerCharacterRepository;
import me.bobbleapp.sdk.database.repository.StickerRepository;
import me.bobbleapp.sdk.database.repository.StickerTextRepository;
import me.bobbleapp.sdk.database.repository.TextStyleRepository;
import me.bobbleapp.sdk.interfaces.DownloadListener;
import me.bobbleapp.sdk.model.ApiFont;
import me.bobbleapp.sdk.model.ApiSticker;
import me.bobbleapp.sdk.model.ApiStickerBackground;
import me.bobbleapp.sdk.model.ApiStickerCharacter;
import me.bobbleapp.sdk.model.ApiStickerText;
import me.bobbleapp.sdk.model.ApiTextStyle;
import me.bobbleapp.sdk.model.StickerCategoryData;
import me.bobbleapp.sdk.networking.Networking;

/**
 * Created by amitshekhar on 23/01/16.
 */
public class StickerCategoryParser extends AsyncTask<Void, Void, Integer> {

    private final DownloadListener downloadListener;
    private final StickerCategoryData stickerCategoryData;
    private final String zipPath;
    private final String unZipPath;
    private String error = null;
    private long stickerCategoryId;

    public StickerCategoryParser(final String zipPath, final String unZipPath, final StickerCategoryData stickerCategoryData, final DownloadListener downloadListener) {
        this.zipPath = zipPath;
        this.unZipPath = unZipPath;
        this.stickerCategoryData = stickerCategoryData;
        this.downloadListener = downloadListener;
    }

    @Override
    protected Integer doInBackground(Void... voids) {
        try {
            stickerCategoryId = stickerCategoryData.getStickerCategories().getStickerCategoryId();
            boolean zipSuccessful = ZipUtil.unzip(zipPath, unZipPath);
            if (zipSuccessful) {
                for (ApiFont apiFont : stickerCategoryData.getFonts()) {
                    Font font = new Font(apiFont);
                    Font tempFont = FontRepository.getFontForId(BobbleSDK.getContext(), font.getId());
                    if (tempFont != null) {
                        font.setLocalPath(tempFont.getLocalPath());
                    }
                    FontRepository.insertOrUpdate(BobbleSDK.getContext(), font);
                    if (font.getLocalPath() == null) {
                        Networking.downloadFont(font);
                    }
                }
                for (ApiTextStyle apiTextStyle : stickerCategoryData.getTextStyles()) {
                    TextStyle textStyle = new TextStyle(apiTextStyle);
                    TextStyleRepository.insertOrUpdate(BobbleSDK.getContext(), textStyle);
                }
                for (ApiStickerBackground apiStickerBackground : stickerCategoryData.getStickerBackgrounds()) {
                    StickerBackground stickerBackground = new StickerBackground(apiStickerBackground);
                    if (FileUtil.exists(unZipPath + "/" + "sticker_category_" + stickerCategoryId + "/" + apiStickerBackground.getStickerBackgroundImage())) {
                        stickerBackground.setLocalImage(unZipPath + "/" + "sticker_category_" + stickerCategoryId + "/" + apiStickerBackground.getStickerBackgroundImage());
                    }
                    StickerBackgroundRepository.insertOrUpdate(BobbleSDK.getContext(), stickerBackground);
                }
                for (ApiStickerCharacter apiStickerCharacter : stickerCategoryData.getStickerCharacters()) {
                    StickerCharacter stickerCharacter = new StickerCharacter(apiStickerCharacter);
                    if (FileUtil.exists(unZipPath + "/" + "sticker_category_" + stickerCategoryId + "/" + apiStickerCharacter.getStickerCharacterImage())) {
                        stickerCharacter.setLocalImage(unZipPath + "/" + "sticker_category_" + stickerCategoryId + "/" + apiStickerCharacter.getStickerCharacterImage());
                    }
                    StickerCharacterRepository.insertOrUpdate(BobbleSDK.getContext(), stickerCharacter);
                }
                for (ApiStickerText apiStickerText : stickerCategoryData.getStickerTexts()) {
                    StickerText stickerText = new StickerText(apiStickerText);
                    if (FileUtil.exists(unZipPath + "/" + "sticker_category_" + stickerCategoryId + "/" + apiStickerText.getStickerTextImage())) {
                        stickerText.setLocalImage(unZipPath + "/" + "sticker_category_" + stickerCategoryId + "/" + apiStickerText.getStickerTextImage());
                    }
                    StickerTextRepository.insertOrUpdate(BobbleSDK.getContext(), stickerText);
                }
                for (ApiSticker apiSticker : stickerCategoryData.getStickers()) {
                    Sticker sticker = new Sticker(apiSticker);
                    sticker.setWaterMark(stickerCategoryData.getWatermarkOriginalUrl());
                    StickerRepository.insertOrUpdate(BobbleSDK.getContext(), sticker);
                }
                StickerCategory stickerCategory = new StickerCategory(stickerCategoryData.getStickerCategories());
                if (FileUtil.exists(unZipPath + "/" + "sticker_category_" + stickerCategoryId + "/" + stickerCategoryData.getStickerCategories().getStickerCategoryImage())) {
                    stickerCategory.setLocalImage(unZipPath + "/" + "sticker_category_" + stickerCategoryId + "/" + stickerCategoryData.getStickerCategories().getStickerCategoryImage());
                }
                StickerCategoryRepository.insertOrUpdate(BobbleSDK.getContext(), stickerCategory);
                if (stickerCategoryData.getWatermarkOriginalUrl() != null) {
                    Networking.downloadWaterMark(stickerCategoryData.getWatermarkOriginalUrl());
                }
            } else {
                error = "zipUnSuccessful";
                return Constants.ERROR;
            }
            return Constants.SUCCESS;
        } catch (Exception e) {
            error = e.toString();
            return Constants.ERROR;
        }
    }

    @Override
    protected void onPostExecute(Integer integer) {
        if (integer == Constants.SUCCESS) {
            downloadListener.onDownloadComplete();
        } else {
            downloadListener.onError(error);
        }
    }


}