package me.bobbleapp.sdk.networking;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.androidnetworking.interfaces.ParsedRequestListener;
import com.google.gson.reflect.TypeToken;

import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.Font;
import me.bobbleapp.sdk.database.WaterMark;
import me.bobbleapp.sdk.database.repository.FontRepository;
import me.bobbleapp.sdk.database.repository.WaterMarkRepository;
import me.bobbleapp.sdk.interfaces.ApiStickerCategoryListListener;
import me.bobbleapp.sdk.interfaces.BobblificationListener;
import me.bobbleapp.sdk.interfaces.DownloadListener;
import me.bobbleapp.sdk.internal.BLog;
import me.bobbleapp.sdk.internal.BobbleUtils;
import me.bobbleapp.sdk.internal.Constants;
import me.bobbleapp.sdk.internal.FileUtil;
import me.bobbleapp.sdk.internal.StickerCategoryParser;
import me.bobbleapp.sdk.model.ApiStickerCategory;
import me.bobbleapp.sdk.model.ColorConfig;
import me.bobbleapp.sdk.model.StickerCategoryData;

/**
 * Created by amitshekhar on 29/07/16.
 */
public final class Networking {

    public static void registerUser(final Context context) {
        HashMap<String, String> params = new HashMap<>();
        params.put("deviceId", BobbleUtils.getDeviceId(context));
        params.put("clientId", BobbleSDK.CLIENT_ID);
        params.put("deviceType", "android");
        params.put("deviceLanguage", BobbleUtils.getLanguage());
        params.put("androidSdkVersion", Build.VERSION.RELEASE);
        params.put("timezone", BobbleUtils.getTimeZone());
        params.put("bobbleSdkVersion", Constants.BOBBLE_SDK_VERSION);
        params.put("deviceInfo", BobbleUtils.getDeviceInfo());

        AndroidNetworking.post(ApiEndPoint.REGISTER)
                .addBodyParameter(params)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        BLog.d("getRegister : " + response.toString());
                        SuccessHandlerUtil.handleOnRegister(context);
                    }

                    @Override
                    public void onError(ANError error) {
                        ErrorHandlerUtil.logError(error, "getRegister");
                    }
                });

    }


    public static void getConfig(final Context context) {
        HashMap<String, String> params = new HashMap<>();
        params.put("deviceId", BobbleUtils.getDeviceId(context));
        params.put("clientId", BobbleSDK.CLIENT_ID);
        params.put("deviceType", "android");
        params.put("androidSdkVersion", Build.VERSION.RELEASE);
        params.put("bobbleSdkVersion", Constants.BOBBLE_SDK_VERSION);

        AndroidNetworking.get(ApiEndPoint.USERS_CONFIG)
                .addQueryParameter(params)
                .getResponseOnlyFromNetwork()
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        BLog.d("getUserConfig : " + response.toString());
                        SuccessHandlerUtil.handleConfigResponse(context, response);
                    }

                    @Override
                    public void onError(ANError error) {
                        ErrorHandlerUtil.logError(error, "getUserConfig");
                    }
                });
    }

    public static void bobblifyMaskBobble(final Context context, final String path, final String gender, final BobblificationListener bobblificationListener) {
        File file = new File(path);
        final SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        final int bobbleTypeFromConfig = sharedPreferences.getInt(Constants.BOBBLE_TYPE, 3);

        HashMap<String, String> params = new HashMap<>();
        params.put("appVersion", Constants.BOBBLE_SDK_VERSION);
        params.put("deviceType", "android");
        params.put("sdkVersion", Build.VERSION.RELEASE);
        params.put("deviceId", BobbleUtils.getDeviceId(context));
        params.put("featurePointsType", "dlibv1");
        params.put("bobbleType", String.valueOf(bobbleTypeFromConfig));
        params.put("colorConfig", new ColorConfig("e0a885", "d79268", "fac4a2").toJsonObjectString());
        params.put("gender", gender);
        params.put("requestFacialLandmarksOriginal", "true");

        AndroidNetworking.upload(ApiEndPoint.BOBBLIFY)
                .addMultipartFile("image", file)
                .setTag(Constants.BOBBLIFICATION)
                .setPriority(Priority.IMMEDIATE)
                .addMultipartParameter(params)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        BLog.d("bobblifyMaskBobble success : " + response.toString());
                        SuccessHandlerUtil.handleBobblifyMaskBobbleResponse(response, path, gender, bobblificationListener);
                    }

                    @Override
                    public void onError(ANError error) {
                        try {
                            if (error.getErrorCode() != 0) {
                                JSONObject jsonObject = new JSONObject(error.getErrorBody());
                                String errorCode = jsonObject.getString("errorCode");
                                bobblificationListener.onError(errorCode);
                            } else {
                                bobblificationListener.onError(error.getErrorDetail());
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            bobblificationListener.onError("onError");
                        }
                        ErrorHandlerUtil.logError(error, "bobblifyMaskBobble");
                    }
                });


    }

    public static void getStickerCategory(int limit, int page, final ApiStickerCategoryListListener apiStickerCategoryListListener) {
        AndroidNetworking.get(ApiEndPoint.NEW_STICKER_PACKS)
                .addQueryParameter("clientId", BobbleSDK.CLIENT_ID)
                .addQueryParameter("limit", String.valueOf(limit))
                .addQueryParameter("page", String.valueOf(page))
                .build()
                .getAsParsed(new TypeToken<List<ApiStickerCategory>>() {
                }, new ParsedRequestListener<List<ApiStickerCategory>>() {
                    @Override
                    public void onResponse(List<ApiStickerCategory> apiStickerCategories) {
                        SuccessHandlerUtil.handleStickerCategoryResponse(apiStickerCategories, apiStickerCategoryListListener);
                    }

                    @Override
                    public void onError(ANError error) {
                        if (error != null) {
                            apiStickerCategoryListListener.onError(error.getErrorDetail());
                        }
                        ErrorHandlerUtil.logError(error, "getStickerCategory");
                    }
                });
    }

    public static void getStickerCategoryDataForId(long id, final DownloadListener downloadListener) {
        AndroidNetworking.get(ApiEndPoint.STICKER_PACK_RESOURCE)
                .addQueryParameter("clientId", BobbleSDK.CLIENT_ID)
                .addQueryParameter("deviceId", BobbleUtils.getDeviceId(BobbleSDK.getContext()))
                .addPathParameter("id", String.valueOf(id))
                .build()
                .getAsParsed(new TypeToken<StickerCategoryData>() {
                }, new ParsedRequestListener<StickerCategoryData>() {
                    @Override
                    public void onResponse(StickerCategoryData stickerCategoryData) {
                        SuccessHandlerUtil.handleStickerCategoryData(stickerCategoryData, downloadListener);
                    }

                    @Override
                    public void onError(ANError error) {
                        if (error != null) {
                            downloadListener.onError(error.getErrorDetail());
                        }
                        ErrorHandlerUtil.logError(error, "getStickerCategoryDataForId");
                    }
                });
    }


    public static void downloadStickerCategoryZip(final StickerCategoryData stickerCategoryData, final DownloadListener downloadListener) {
        final String dirPath = BobbleUtils.getDirPath();
        final String fileName = BobbleUtils.getUniqueFileName(String.valueOf(stickerCategoryData.getStickerCategories().getStickerCategoryId()), ".zip");
        final String zipPath = dirPath + File.separator + fileName;
        final String unZipPath = dirPath + File.separator + "stickerPack";

        AndroidNetworking.download(stickerCategoryData.getFileUrlXHDPI(), dirPath, fileName)
                .build()
                .startDownload(new com.androidnetworking.interfaces.DownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        new StickerCategoryParser(zipPath, unZipPath, stickerCategoryData, downloadListener).execute();
                    }

                    @Override
                    public void onError(ANError error) {
                        ErrorHandlerUtil.logError(error, "downloadStickerCategoryZip");
                        downloadListener.onError("onDownloadFailed");
                    }
                });
    }

    public static void downloadFont(final Font font) {
        final String dirPath = BobbleUtils.getDirPath();
        final String fileName = BobbleUtils.getUniqueFileName("font", "." + FileUtil.getExtension(font.getFontUrl()));

        AndroidNetworking.download(font.getFontUrl(), dirPath, fileName)
                .build()
                .startDownload(new com.androidnetworking.interfaces.DownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        font.setLocalPath(dirPath + File.separator + fileName);
                        FontRepository.insertOrUpdate(BobbleSDK.getContext(), font);
                    }

                    @Override
                    public void onError(ANError error) {
                        ErrorHandlerUtil.logError(error, "downloadFont");
                    }
                });

    }

    public static void downloadWaterMark(final String url) {
        final String dirPath = BobbleUtils.getDirPath();
        final String fileName = BobbleUtils.getUniqueFileName("watermark", ".png");

        AndroidNetworking.download(url, dirPath, fileName)
                .build()
                .startDownload(new com.androidnetworking.interfaces.DownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        if (WaterMarkRepository.getWaterMarkForImageUrl(BobbleSDK.getContext(), url) == null) {
                            WaterMark waterMark = new WaterMark();
                            waterMark.setImageUrl(url);
                            waterMark.setLocalPath(dirPath + File.separator + fileName);
                            WaterMarkRepository.insertOrUpdate(BobbleSDK.getContext(), waterMark);
                        }
                    }

                    @Override
                    public void onError(ANError error) {
                        ErrorHandlerUtil.logError(error, "downloadWaterMark");
                    }
                });
    }

}
