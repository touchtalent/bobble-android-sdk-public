package me.bobbleapp.sdk.networking;

import com.androidnetworking.error.ANError;

import me.bobbleapp.sdk.internal.BLog;

/**
 * Created by amitshekhar on 29/07/16.
 */
public final class ErrorHandlerUtil {

    public static void logError(ANError error, String reference) {
        try {
            if (error != null) {
                if (error.getErrorCode() != 0) {
                    BLog.d(reference + " onError errorCode : " + error.getErrorCode());
                    BLog.d(reference + " onError errorBody : " + error.getErrorBody());
                    BLog.d(reference + " onError errorDetail : " + error.getErrorDetail());
                } else {
                    BLog.d(reference + " onError errorDetail : " + error.getErrorDetail());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
