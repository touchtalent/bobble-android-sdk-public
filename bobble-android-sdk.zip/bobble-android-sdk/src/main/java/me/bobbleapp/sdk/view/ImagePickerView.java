package me.bobbleapp.sdk.view;

/**
 * Created by amitshekhar on 25/07/16.
 */
public interface ImagePickerView extends BaseView {


}
