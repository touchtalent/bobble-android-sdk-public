package me.bobbleapp.sdk.model;

/**
 * Created by amitshekhar on 22/01/16.
 */
public class ApiStickerText {
    private long stickerTextId;
    private String stickerTextImageHDPI;
    private String stickerTextImageXHDPI;
    private String stickerTextImageXXHDPI;
    private String stickerTextImage;

    public long getStickerTextId() {
        return stickerTextId;
    }

    public void setStickerTextId(long stickerTextId) {
        this.stickerTextId = stickerTextId;
    }

    public String getStickerTextImageHDPI() {
        return stickerTextImageHDPI;
    }

    public void setStickerTextImageHDPI(String stickerTextImageHDPI) {
        this.stickerTextImageHDPI = stickerTextImageHDPI;
    }

    public String getStickerTextImageXHDPI() {
        return stickerTextImageXHDPI;
    }

    public void setStickerTextImageXHDPI(String stickerTextImageXHDPI) {
        this.stickerTextImageXHDPI = stickerTextImageXHDPI;
    }

    public String getStickerTextImageXXHDPI() {
        return stickerTextImageXXHDPI;
    }

    public void setStickerTextImageXXHDPI(String stickerTextImageXXHDPI) {
        this.stickerTextImageXXHDPI = stickerTextImageXXHDPI;
    }

    public String getStickerTextImage() {
        return stickerTextImage;
    }

    public void setStickerTextImage(String stickerTextImage) {
        this.stickerTextImage = stickerTextImage;
    }
}
