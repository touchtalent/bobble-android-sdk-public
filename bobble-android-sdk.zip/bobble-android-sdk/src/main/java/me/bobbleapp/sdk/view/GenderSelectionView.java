package me.bobbleapp.sdk.view;

/**
 * Created by amitshekhar on 26/07/16.
 */
public interface GenderSelectionView extends BaseView {

    void navigate(String gender);

}
