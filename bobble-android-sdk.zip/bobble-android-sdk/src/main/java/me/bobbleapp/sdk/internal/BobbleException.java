package me.bobbleapp.sdk.internal;

/**
 * Created by amitshekhar on 15/01/16.
 */

/**
 * Represents an error condition specific to the Bobble SDK for Android.
 */
public class BobbleException extends RuntimeException {
    static final long serialVersionUID = 1;

    /**
     * Constructs a new BobbleException.
     */
    public BobbleException() {
        super();
    }

    /**
     * Constructs a new BobbleException.
     *
     * @param message the detail message of this exception
     */
    public BobbleException(String message) {
        super(message);
    }

    /**
     * Constructs a new BobbleException.
     *
     * @param format the format string (see {@link java.util.Formatter#format})
     * @param args   the list of arguments passed to the formatter.
     */
    public BobbleException(String format, Object... args) {
        this(String.format(format, args));
    }

    /**
     * Constructs a new BobbleException.
     *
     * @param message   the detail message of this exception
     * @param throwable the cause of this exception
     */
    public BobbleException(String message, Throwable throwable) {
        super(message, throwable);
    }

    /**
     * Constructs a new BobbleException.
     *
     * @param throwable the cause of this exception
     */
    public BobbleException(Throwable throwable) {
        super(throwable);
    }

    @Override
    public String toString() {
        // Throwable.toString() returns "BobbleException:{message}". Returning just "{message}"
        // should be fine here.
        return getMessage();
    }
}
