package me.bobbleapp.sdk.model;

import java.util.List;

/**
 * Created by amitshekhar on 24/06/16.
 */
public class SeedModel {

    private List<ApiStickerCategory> stickerCategories;
    private List<ApiSticker> stickers;
    private List<ApiStickerBackground> stickerBackgrounds;
    private List<ApiStickerCharacter> stickerCharacters;
    private List<ApiStickerText> stickerTexts;
    private List<ApiTextStyle> textStyles;
    private List<ApiFont> fonts;

    public List<ApiStickerCategory> getStickerCategories() {
        return stickerCategories;
    }

    public void setStickerCategories(List<ApiStickerCategory> stickerCategories) {
        this.stickerCategories = stickerCategories;
    }

    public List<ApiSticker> getStickers() {
        return stickers;
    }

    public void setStickers(List<ApiSticker> stickers) {
        this.stickers = stickers;
    }

    public List<ApiStickerBackground> getStickerBackgrounds() {
        return stickerBackgrounds;
    }

    public void setStickerBackgrounds(List<ApiStickerBackground> stickerBackgrounds) {
        this.stickerBackgrounds = stickerBackgrounds;
    }

    public List<ApiStickerCharacter> getStickerCharacters() {
        return stickerCharacters;
    }

    public void setStickerCharacters(List<ApiStickerCharacter> stickerCharacters) {
        this.stickerCharacters = stickerCharacters;
    }

    public List<ApiStickerText> getStickerTexts() {
        return stickerTexts;
    }

    public void setStickerTexts(List<ApiStickerText> stickerTexts) {
        this.stickerTexts = stickerTexts;
    }

    public List<ApiTextStyle> getTextStyles() {
        return textStyles;
    }

    public void setTextStyles(List<ApiTextStyle> textStyles) {
        this.textStyles = textStyles;
    }

    public List<ApiFont> getFonts() {
        return fonts;
    }

    public void setFonts(List<ApiFont> fonts) {
        this.fonts = fonts;
    }
}
