package me.bobbleapp.sdk.database.repository;

import android.content.Context;

import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.StickerCharacter;
import me.bobbleapp.sdk.database.StickerCharacterDao;

public class StickerCharacterRepository {

    public static void insertOrUpdate(Context context, StickerCharacter stickerCharacter) {
        getStickerCharacterDao(context).insertOrReplace(stickerCharacter);
    }

    public static void clearStickerCharacters(Context context) {
        getStickerCharacterDao(context).deleteAll();
    }

    public static boolean isEmpty(Context context) {
        return (getStickerCharacterDao(context).count() == 0);
    }

    public static void deleteStickerCharacterWithId(Context context, long id) {
        getStickerCharacterDao(context).delete(getStickerCharacterForId(context, id));
    }

    public static List<StickerCharacter> getAllStickerCharacters(Context context) {
        return getStickerCharacterDao(context).loadAll();
    }

    public static StickerCharacter getStickerCharacterForId(Context context, long id) {
        return getStickerCharacterDao(context).load(id);
    }

    public static StickerCharacterDao getStickerCharacterDao(Context c) {
        return BobbleSDK.getDaoSession().getStickerCharacterDao();
    }
}
