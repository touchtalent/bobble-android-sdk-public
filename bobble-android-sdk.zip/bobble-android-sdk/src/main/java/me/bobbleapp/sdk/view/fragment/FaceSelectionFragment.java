package me.bobbleapp.sdk.view.fragment;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import me.bobbleapp.sdk.R;
import me.bobbleapp.sdk.faceselector.CropImageView;
import me.bobbleapp.sdk.faceselector.util.ImageViewUtil;
import me.bobbleapp.sdk.interfaces.FragmentCallback;
import me.bobbleapp.sdk.internal.AndroidFaceDetector;
import me.bobbleapp.sdk.internal.BLog;
import me.bobbleapp.sdk.internal.Constants;
import me.bobbleapp.sdk.presenter.FaceSelectionPresenter;
import me.bobbleapp.sdk.view.FaceSelectionView;
import me.bobbleapp.sdk.view.activity.BobbleCreationActivity;

/**
 * Created by amitshekhar on 27/07/16.
 */
public class FaceSelectionFragment extends Fragment implements FaceSelectionView, View.OnClickListener {

    private static final String TAG = FaceSelectionFragment.class.getSimpleName();
    private FaceSelectionPresenter presenter;
    private CropImageView imageViewCrop;
    private Toolbar toolbar;
    private AndroidFaceDetector androidFaceDetector;
    private RectF cropRect;
    private ImageView actionBarDone;
    private LinearLayout layoutRotate;
    private TextView header;
    private Bitmap bitmap;
    private boolean canShowFaceDialog = true;
    private FragmentCallback fragmentCallback;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        BLog.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        presenter = new FaceSelectionPresenter();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        BLog.d(TAG, "onCreateView");
        View view = inflater.inflate(R.layout.fragment_bobble_face_selection, container, false);
        cropRect = new RectF();
        initializeView(view);
        return view;
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        BLog.d(TAG, "onViewCreated");
        super.onViewCreated(view, savedInstanceState);
        presenter.setView(this);
        setGlobalLayoutListener();
    }

    @Override
    public void onAttach(Context context) {
        BLog.d(TAG, "onAttach");
        super.onAttach(context);
        try {
            fragmentCallback = (FragmentCallback) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement FragmentCallback");
        }
    }

    @Override
    public void onStop() {
        BLog.d(TAG, "onStop");
        super.onStop();
        presenter.stop();
    }

    @Override
    public void onResume() {
        BLog.d(TAG, "onResume");
        super.onResume();
        presenter.resume();
    }

    @Override
    public void onStart() {
        BLog.d(TAG, "onStart");
        super.onStart();
        presenter.start();
    }

    @Override
    public void onPause() {
        BLog.d(TAG, "onPause");
        super.onPause();
        presenter.pause();
    }

    @Override
    public void onDestroy() {
        BLog.d(TAG, "onDestroy");
        super.onDestroy();
        presenter.destroy();
        presenter = null;
        androidFaceDetector = null;
        releaseBitmapMemory();
    }

    @Override
    public void onDestroyView() {
        BLog.d(TAG, "onDestroyView");
        super.onDestroyView();
    }

    @Override
    public void singleFaceDetection() {
        Rect imageRect = ImageViewUtil.getBitmapRectCenterInside(fragmentCallback.getInputBitmap().getWidth(), fragmentCallback.getInputBitmap().getHeight(), imageViewCrop.getWidth(), imageViewCrop.getHeight());
        float widthFactor = (float) imageViewCrop.getWidth() / (float) fragmentCallback.getInputBitmap().getWidth();
        float heightFactor = (float) imageViewCrop.getHeight() / (float) fragmentCallback.getInputBitmap().getHeight();
        float scaleFactor = 1f;
        if (widthFactor < heightFactor) {
            scaleFactor = widthFactor;
        } else {
            scaleFactor = heightFactor;
        }
        int selectedIndex = 0;
        float maxEyeDistance = androidFaceDetector.getFaces()[0].eyesDistance();
        for (int i = 0; i < androidFaceDetector.getNumberOfFaceDetected(); i++) {
            if (maxEyeDistance < androidFaceDetector.getFaces()[i].eyesDistance()) {
                maxEyeDistance = androidFaceDetector.getFaces()[i].eyesDistance();
                selectedIndex = i;
            }
        }
        PointF midPoint = new PointF();
        androidFaceDetector.getFaces()[selectedIndex].getMidPoint(midPoint);
        // Displacing the mid point a-bit in the y-direction to align it with the face center
        midPoint.y += maxEyeDistance / 10.0;
        cropRect.left = (int) (imageRect.left + (midPoint.x - maxEyeDistance * 1.9) * scaleFactor);
        cropRect.top = (int) (imageRect.top + (midPoint.y - maxEyeDistance * 2.2) * scaleFactor);
        cropRect.right = (int) (imageRect.left + (midPoint.x + maxEyeDistance * 1.9) * scaleFactor);
        cropRect.bottom = (int) (imageRect.top + (midPoint.y + maxEyeDistance * 2.3) * scaleFactor);
        imageViewCrop.initializeRect((int) cropRect.top, (int) cropRect.left, (int) cropRect.right, (int) cropRect.bottom);
        actionBarDone.setVisibility(View.VISIBLE);
        actionBarDone.setImageResource(R.drawable.ic_bobble_next);
        layoutRotate.setVisibility(View.VISIBLE);
        header.setText(getActivity().getString(R.string.choose_one_face));
        canShowFaceDialog = false;
    }

    @Override
    public void multipleFaceDetection() {
        Rect imageRect = ImageViewUtil.getBitmapRectCenterInside(fragmentCallback.getInputBitmap().getWidth(), fragmentCallback.getInputBitmap().getHeight(), imageViewCrop.getWidth(), imageViewCrop.getHeight());
        float widthFactor = (float) imageViewCrop.getWidth() / (float) fragmentCallback.getInputBitmap().getWidth();
        float heightFactor = (float) imageViewCrop.getHeight() / (float) fragmentCallback.getInputBitmap().getHeight();
        float scaleFactor = 1f;
        if (widthFactor < heightFactor) {
            scaleFactor = widthFactor;
        } else {
            scaleFactor = heightFactor;
        }
        int selectedIndex = 0;
        float maxEyeDistance = androidFaceDetector.getFaces()[0].eyesDistance();
        for (int i = 0; i < androidFaceDetector.getNumberOfFaceDetected(); i++) {
            if (maxEyeDistance < androidFaceDetector.getFaces()[i].eyesDistance()) {
                maxEyeDistance = androidFaceDetector.getFaces()[i].eyesDistance();
                selectedIndex = i;
            }
        }
        PointF midPoint = new PointF();
        androidFaceDetector.getFaces()[selectedIndex].getMidPoint(midPoint);
        // Displacing the mid point a-bit in the y-direction to align it with the face center
        midPoint.y += maxEyeDistance / 10.0;
        cropRect.left = (int) (imageRect.left + (midPoint.x - maxEyeDistance * 1.9) * scaleFactor);
        cropRect.top = (int) (imageRect.top + (midPoint.y - maxEyeDistance * 2.2) * scaleFactor);
        cropRect.right = (int) (imageRect.left + (midPoint.x + maxEyeDistance * 1.9) * scaleFactor);
        cropRect.bottom = (int) (imageRect.top + (midPoint.y + maxEyeDistance * 2.3) * scaleFactor);
        imageViewCrop.initializeRect((int) cropRect.top, (int) cropRect.left, (int) cropRect.right, (int) cropRect.bottom);
        actionBarDone.setVisibility(View.VISIBLE);
        actionBarDone.setImageResource(R.drawable.ic_bobble_next);
        layoutRotate.setVisibility(View.VISIBLE);
        header.setText(getActivity().getString(R.string.choose_one_face));
        if (canShowFaceDialog) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle(getString(R.string.select_only_one_face));
            builder.setMessage(getString(R.string.more_than_one_face));
            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
            try {
                builder.show();
                canShowFaceDialog = false;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void noFaceDetection() {
        cropRect.top = (int) (imageViewCrop.getHeight() * (0.30));
        cropRect.left = (int) (imageViewCrop.getWidth() * (0.30));
        cropRect.right = (int) (imageViewCrop.getWidth() * (0.70));
        cropRect.bottom = (int) (imageViewCrop.getHeight() * (0.70));
        imageViewCrop.initializeRect((int) cropRect.top, (int) cropRect.left, (int) cropRect.right, (int) cropRect.bottom);
        actionBarDone.setVisibility(View.VISIBLE);
        actionBarDone.setImageResource(R.drawable.ic_bobble_next);
        layoutRotate.setVisibility(View.VISIBLE);
        header.setText(getActivity().getString(R.string.choose_one_face));
        if (canShowFaceDialog) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle(R.string.no_face_detected);
            builder.setMessage(getString(R.string.no_face_detected_dialog));
            builder.setPositiveButton(getString(R.string.Proceed), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
            builder.setNegativeButton(R.string.retake, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                    openFragment("imagePicker");
                }
            });
            try {
                builder.show();
                canShowFaceDialog = false;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void navigate() {
        fragmentCallback.setInputBitmap(imageViewCrop.getCroppedImage());
        openFragment("genderSelection");
    }

    @Override
    public void rotate(Bitmap bitmap) {
        imageViewCrop.setImageBitmap(bitmap);
        this.bitmap = bitmap;
    }

    @Override
    public void onRotateError() {
        Toast.makeText(getActivity().getApplicationContext(), getActivity().getApplicationContext().getString(R.string.some_error_occurred), Toast.LENGTH_SHORT).show();
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.popBackStack();
    }

    @Override
    public Context context() {
        return getActivity().getApplicationContext();
    }

    private void initializeView(View view) {
        imageViewCrop = (CropImageView) view.findViewById(R.id.imageViewCrop);
        toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        if (bitmap == null && fragmentCallback.getInputBitmap() != null) {
            try {
                bitmap = fragmentCallback.getInputBitmap().copy(fragmentCallback.getInputBitmap().getConfig(), true);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getActivity().getApplicationContext(), getActivity().getApplicationContext().getString(R.string.image_not_supported), Toast.LENGTH_SHORT).show();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                fragmentManager.popBackStack();
                return;
            }
        }
        imageViewCrop.setImageBitmap(bitmap);
        ((BobbleCreationActivity) getActivity()).setSupportActionBar(toolbar);
        actionBarDone = (ImageView) view.findViewById(R.id.ivManage);
        header = (TextView) view.findViewById(R.id.tv_header);
        layoutRotate = (LinearLayout) view.findViewById(R.id.layoutRotate);
        actionBarDone.setOnClickListener(this);
        layoutRotate.setOnClickListener(this);
    }

    private void setGlobalLayoutListener() {
        ViewTreeObserver viewTreeObserver = imageViewCrop.getViewTreeObserver();
        viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    imageViewCrop.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                } else {
                    imageViewCrop.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                }
                androidFaceDetector = new AndroidFaceDetector(fragmentCallback.getInputBitmap().copy(Bitmap.Config.RGB_565, false), 5);
                presenter.onFaceDetection(androidFaceDetector);
            }
        });
    }

    public void openFragment(String type) {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        switch (type) {
            case "imagePicker":
                fragmentManager.popBackStack(Constants.IMAGE_PICKER_BACK_STACK, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                break;
            case "genderSelection":
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                GenderSelectionFragment genderSelectionFragment = new GenderSelectionFragment();
                fragmentTransaction.replace(R.id.fragmentContainer, genderSelectionFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                break;
        }
    }


    @Override
    public void onClick(View view) {
        final int id = view.getId();
        if (id == R.id.ivManage) {
            BLog.d(TAG, "buttonDone clicked");
            presenter.onNext();
        } else if (id == R.id.layoutRotate) {
            BLog.d(TAG, "buttonRotate clicked");
            presenter.onRotateImage(this.bitmap);
        }
    }

    private void releaseBitmapMemory() {
        try {
            if (bitmap != null) {
                bitmap.recycle();
                bitmap = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
