package me.bobbleapp.sdk.presenter;

import me.bobbleapp.sdk.view.ImagePickerView;

/**
 * Created by amitshekhar on 25/07/16.
 */
public class ImagePickerPresenter implements Presenter {

    private ImagePickerView imagePickerView;

    public ImagePickerPresenter() {

    }

    public void setView(ImagePickerView imagePickerView) {
        this.imagePickerView = imagePickerView;
    }

    @Override
    public void resume() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void destroy() {
        this.imagePickerView = null;
    }

    @Override
    public void stop() {

    }

    @Override
    public void start() {

    }
}
