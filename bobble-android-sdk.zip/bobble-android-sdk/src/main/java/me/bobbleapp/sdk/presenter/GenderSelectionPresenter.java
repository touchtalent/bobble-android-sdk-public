package me.bobbleapp.sdk.presenter;

import me.bobbleapp.sdk.view.GenderSelectionView;

/**
 * Created by amitshekhar on 26/07/16.
 */
public class GenderSelectionPresenter implements Presenter {

    private GenderSelectionView genderSelectionView;

    public GenderSelectionPresenter() {

    }

    public void setView(GenderSelectionView genderSelectionView) {
        this.genderSelectionView = genderSelectionView;
    }


    public void onMaleGenderSelection() {
        this.genderSelectionView.navigate("male");
    }

    public void onFemaleGenderSelection() {
        this.genderSelectionView.navigate("female");
    }

    @Override
    public void resume() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void destroy() {
        this.genderSelectionView = null;
    }

    @Override
    public void stop() {

    }

    @Override
    public void start() {

    }
}
