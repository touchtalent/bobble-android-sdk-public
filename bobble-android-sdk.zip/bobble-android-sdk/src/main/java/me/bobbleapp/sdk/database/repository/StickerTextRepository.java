package me.bobbleapp.sdk.database.repository;

import android.content.Context;

import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.StickerText;
import me.bobbleapp.sdk.database.StickerTextDao;

public class StickerTextRepository {

    public static void insertOrUpdate(Context context, StickerText stickerText) {
        getStickerTextDao(context).insertOrReplace(stickerText);
    }

    public static void clearStickerTexts(Context context) {
        getStickerTextDao(context).deleteAll();
    }

    public static boolean isEmpty(Context context) {
        return (getStickerTextDao(context).count() == 0);
    }

    public static void deleteStickerTextWithId(Context context, long id) {
        getStickerTextDao(context).delete(getStickerTextForId(context, id));
    }

    public static List<StickerText> getAllStickerTexts(Context context) {
        return getStickerTextDao(context).loadAll();
    }

    public static StickerText getStickerTextForId(Context context, long id) {
        return getStickerTextDao(context).load(id);
    }

    public static StickerTextDao getStickerTextDao(Context c) {
        return BobbleSDK.getDaoSession().getStickerTextDao();
    }
}
