package me.bobbleapp.sdk.model;

import java.util.List;

/**
 * Created by amitshekhar on 22/01/16.
 */
public class StickerCategoryData {

    private ApiStickerCategory stickerCategories;
    private List<ApiSticker> stickers;
    private List<ApiStickerBackground> stickerBackgrounds;
    private List<ApiStickerCharacter> stickerCharacters;
    private List<ApiStickerText> stickerTexts;
    private List<ApiTextStyle> textStyles;
    private List<ApiFont> fonts;
    private String fileUrlHDPI;
    private String fileUrlXHDPI;
    private String fileUrlXXHDPI;
    private String watermarkOriginalUrl;

    public ApiStickerCategory getStickerCategories() {
        return stickerCategories;
    }

    public void setStickerCategories(ApiStickerCategory stickerCategories) {
        this.stickerCategories = stickerCategories;
    }

    public List<ApiSticker> getStickers() {
        return stickers;
    }

    public void setStickers(List<ApiSticker> stickers) {
        this.stickers = stickers;
    }

    public List<ApiStickerBackground> getStickerBackgrounds() {
        return stickerBackgrounds;
    }

    public void setStickerBackgrounds(List<ApiStickerBackground> stickerBackgrounds) {
        this.stickerBackgrounds = stickerBackgrounds;
    }

    public List<ApiStickerCharacter> getStickerCharacters() {
        return stickerCharacters;
    }

    public void setStickerCharacters(List<ApiStickerCharacter> stickerCharacters) {
        this.stickerCharacters = stickerCharacters;
    }

    public List<ApiStickerText> getStickerTexts() {
        return stickerTexts;
    }

    public void setStickerTexts(List<ApiStickerText> stickerTexts) {
        this.stickerTexts = stickerTexts;
    }

    public List<ApiTextStyle> getTextStyles() {
        return textStyles;
    }

    public void setTextStyles(List<ApiTextStyle> textStyles) {
        this.textStyles = textStyles;
    }

    public List<ApiFont> getFonts() {
        return fonts;
    }

    public void setFonts(List<ApiFont> fonts) {
        this.fonts = fonts;
    }

    public String getFileUrlHDPI() {
        return fileUrlHDPI;
    }

    public void setFileUrlHDPI(String fileUrlHDPI) {
        this.fileUrlHDPI = fileUrlHDPI;
    }

    public String getFileUrlXHDPI() {
        return fileUrlXHDPI;
    }

    public void setFileUrlXHDPI(String fileUrlXHDPI) {
        this.fileUrlXHDPI = fileUrlXHDPI;
    }

    public String getFileUrlXXHDPI() {
        return fileUrlXXHDPI;
    }

    public void setFileUrlXXHDPI(String fileUrlXXHDPI) {
        this.fileUrlXXHDPI = fileUrlXXHDPI;
    }

    public String getWatermarkOriginalUrl() {
        return watermarkOriginalUrl;
    }

    public void setWatermarkOriginalUrl(String watermarkOriginalUrl) {
        this.watermarkOriginalUrl = watermarkOriginalUrl;
    }
}
