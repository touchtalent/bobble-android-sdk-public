package me.bobbleapp.sdk.view.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import me.bobbleapp.sdk.R;
import me.bobbleapp.sdk.interfaces.FragmentCallback;
import me.bobbleapp.sdk.internal.BLog;
import me.bobbleapp.sdk.internal.Constants;
import me.bobbleapp.sdk.internal.NetworkUtil;
import me.bobbleapp.sdk.presenter.GenderSelectionPresenter;
import me.bobbleapp.sdk.view.GenderSelectionView;
import me.bobbleapp.sdk.view.activity.BobbleCreationActivity;

/**
 * Created by amitshekhar on 25/07/16.
 */
public class GenderSelectionFragment extends Fragment implements GenderSelectionView, View.OnClickListener {

    private static final String TAG = GenderSelectionFragment.class.getSimpleName();
    private GenderSelectionPresenter presenter;
    private Toolbar toolbar;
    private FragmentCallback fragmentCallback;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        BLog.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        presenter = new GenderSelectionPresenter();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bobble_gender_selection, container, false);
        initializeView(view);
        setOnClickListeners(view);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        BLog.d(TAG, "onViewCreated");
        super.onViewCreated(view, savedInstanceState);
        presenter.setView(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            fragmentCallback = (FragmentCallback) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement FragmentCallback");
        }
    }

    @Override
    public void onStop() {
        BLog.d(TAG, "onStop");
        super.onStop();
        presenter.stop();
    }

    @Override
    public void onResume() {
        BLog.d(TAG, "onResume");
        super.onResume();
        presenter.resume();
    }

    @Override
    public void onStart() {
        BLog.d(TAG, "onStart");
        super.onStart();
        presenter.start();
    }

    @Override
    public void onPause() {
        BLog.d(TAG, "onPause");
        super.onPause();
        presenter.pause();
    }

    @Override
    public void onDestroy() {
        BLog.d(TAG, "onDestroy");
        super.onDestroy();
        presenter.destroy();
        presenter = null;
    }

    @Override
    public void onDestroyView() {
        BLog.d(TAG, "onDestroyView");
        super.onDestroyView();
    }

    @Override
    public void navigate(String gender) {
        try {
            if (NetworkUtil.isConnected(getActivity().getApplicationContext())) {
                openFragment(gender);
            } else {
                Toast.makeText(getActivity().getApplicationContext(), getActivity().getApplicationContext().getString(R.string.no_internet_connection), Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            openFragment(gender);
            BLog.d(TAG, "access network state permission not granted");
        }
    }

    @Override
    public Context context() {
        return getActivity().getApplicationContext();
    }

    @Override
    public void onClick(View view) {
        final int id = view.getId();
        if (id == R.id.buttonMale) {
            BLog.d(TAG, "buttonMale clicked");
            presenter.onMaleGenderSelection();
        } else if (id == R.id.buttonFemale) {
            BLog.d(TAG, "buttonFemale clicked");
            presenter.onFemaleGenderSelection();
        }
    }

    private void initializeView(View view) {
        ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
        imageView.setImageBitmap(fragmentCallback.getInputBitmap());
        toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        ((TextView) view.findViewById(R.id.tv_header)).setText(getActivity().getApplicationContext().getString(R.string.select_gender));
        ((BobbleCreationActivity) getActivity()).setSupportActionBar(toolbar);
    }

    private void setOnClickListeners(View view) {
        view.findViewById(R.id.buttonMale).setOnClickListener(this);
        view.findViewById(R.id.buttonFemale).setOnClickListener(this);
    }

    private void openFragment(String gender) {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        BobbleProgressFragment bobbleProgressFragment = new BobbleProgressFragment();
        Bundle args = new Bundle();
        args.putString("gender", gender);
        bobbleProgressFragment.setArguments(args);
        fragmentTransaction.replace(R.id.fragmentContainer, bobbleProgressFragment, Constants.BOBBLE_PROCESS_FRAGMENT);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

}