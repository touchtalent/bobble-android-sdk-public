package me.bobbleapp.sdk.database.repository;

import android.content.Context;

import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.Sticker;
import me.bobbleapp.sdk.database.StickerDao;

public class StickerRepository {

    public static void insertOrUpdate(Context context, Sticker sticker) {
        getStickerDao(context).insertOrReplace(sticker);

    }

    public static void clearStickers(Context context) {
        getStickerDao(context).deleteAll();
    }

    public static boolean isEmpty(Context context) {
        return (getStickerDao(context).count() == 0);
    }

    public static void deleteStickerWithId(Context context, long id) {
        getStickerDao(context).delete(getStickerForId(context, id));
    }

    public static List<Sticker> getAllStickers(Context context) {
        return getStickerDao(context).loadAll();
    }

    public static Sticker getStickerForId(Context context, long id) {
        return getStickerDao(context).load(id);
    }

    public static StickerDao getStickerDao(Context c) {
        return BobbleSDK.getDaoSession().getStickerDao();
    }
}
