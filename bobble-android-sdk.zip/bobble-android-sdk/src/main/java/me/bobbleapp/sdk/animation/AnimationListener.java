package me.bobbleapp.sdk.animation;

/**
 * Created by amitshekhar on 01/08/15.
 */
public interface AnimationListener {

    /**
     * This method is called when the animation ends.
     *
     * @param animation The Animation object.
     */
    public void onAnimationEnd(Animation animation);
}