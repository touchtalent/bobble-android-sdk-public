package me.bobbleapp.sdk.database.repository;

import android.content.Context;

import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.BobbleHead;
import me.bobbleapp.sdk.database.BobbleHeadDao;

public class BobbleHeadRepository {

    public static void insertOrUpdate(Context context, BobbleHead BobbleHead) {
        getBobbleHeadDao(context).insertOrReplace(BobbleHead);
    }

    public static void clearBobbleHeads(Context context) {
        getBobbleHeadDao(context).deleteAll();
    }

    public static boolean isEmpty(Context context) {
        return (getBobbleHeadDao(context).count() == 0);
    }

    public static void deleteBobbleHeadWithId(Context context, long id) {
        getBobbleHeadDao(context).delete(getBobbleHeadForId(context, id));
    }

    public static List<BobbleHead> getAllBobbleHeads(Context context) {
        return getBobbleHeadDao(context).loadAll();
    }

    public static List<BobbleHead> getAllBobbleHeadsForFaceId(Context context, long faceId) {
        return getBobbleHeadDao(context)._queryFace_BobbleHeadList(faceId);
    }

    public static BobbleHead getBobbleHeadForId(Context context, long id) {
        return getBobbleHeadDao(context).load(id);
    }

    public static BobbleHeadDao getBobbleHeadDao(Context c) {
        return BobbleSDK.getDaoSession().getBobbleHeadDao();
    }
}
