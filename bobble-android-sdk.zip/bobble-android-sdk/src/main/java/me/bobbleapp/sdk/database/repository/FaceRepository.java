package me.bobbleapp.sdk.database.repository;

import android.content.Context;

import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.Face;
import me.bobbleapp.sdk.database.FaceDao;

public class FaceRepository {

    public static void insertOrUpdate(Context context, Face face) {
        getFaceDao(context).insertOrReplace(face);
    }

    public static void clearFaces(Context context) {
        getFaceDao(context).deleteAll();
    }

    public static boolean isEmpty(Context context) {
        return (getFaceDao(context).count() == 0);
    }

    public static void deleteFaceWithId(Context context, long id) {
        getFaceDao(context).delete(getFaceForId(context, id));
    }

    public static List<Face> getAllFaces(Context context) {
        return getFaceDao(context).loadAll();
    }

    public static Face getFaceForId(Context context, long id) {
        return getFaceDao(context).load(id);
    }

    public static FaceDao getFaceDao(Context c) {
        return BobbleSDK.getDaoSession().getFaceDao();
    }
}
