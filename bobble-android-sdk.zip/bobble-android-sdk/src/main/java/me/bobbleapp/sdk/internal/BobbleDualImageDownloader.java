package me.bobbleapp.sdk.internal;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.os.AsyncTask;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.DownloadListener;
import com.touchtalent.bobbleapp.mask.BobbleComposedMask;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.BobbleHead;
import me.bobbleapp.sdk.database.Face;
import me.bobbleapp.sdk.database.repository.BobbleHeadRepository;
import me.bobbleapp.sdk.database.repository.FaceRepository;
import me.bobbleapp.sdk.interfaces.BobblificationListener;
import me.bobbleapp.sdk.networking.ErrorHandlerUtil;

/**
 * Created by amitshekhar on 24/01/16.
 */
public class BobbleDualImageDownloader {

    private final BobblificationListener mBobblificationListener;
    private final String bobbleUrl;
    private final String maskUrl;
    private final String dirPath;
    private final String bobbleFileName;
    private final String maskFileName;
    private int numberOfImageDownloaded = 0;
    private final int numOfMasks;
    private final String gender;
    private final JSONObject featuresPoints;
    private final JSONArray maskROIArray;


    public BobbleDualImageDownloader(final String bobbleUrl, final String maskUrl, final String gender, final int numOfMasks, final JSONObject featuresPoints, final JSONArray maskROIArray, final BobblificationListener bobblificationListener) {
        this.bobbleUrl = bobbleUrl;
        this.maskUrl = maskUrl;
        this.gender = gender;
        this.numOfMasks = numOfMasks;
        this.featuresPoints = featuresPoints;
        this.maskROIArray = maskROIArray;
        this.mBobblificationListener = bobblificationListener;
        this.dirPath = BobbleUtils.getDirPath();
        this.bobbleFileName = BobbleUtils.getUniqueFileName("bobble", "." + FileUtil.getExtension(bobbleUrl));
        this.maskFileName = BobbleUtils.getUniqueFileName("mask", "stream");
    }

    public void download() {

        AndroidNetworking.download(bobbleUrl, dirPath, bobbleFileName)
                .setPriority(Priority.IMMEDIATE)
                .setTag(Constants.BOBBLIFICATION)
                .build()
                .startDownload(new DownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        checkIfBothImageDownloaded();
                    }

                    @Override
                    public void onError(ANError error) {
                        ErrorHandlerUtil.logError(error, "bobbleImageDownloader");
                        if (error != null) {
                            mBobblificationListener.onError(error.getErrorDetail());
                        } else {
                            mBobblificationListener.onError("onError");
                        }
                    }
                });

        AndroidNetworking.download(maskUrl, dirPath, maskFileName)
                .setPriority(Priority.IMMEDIATE)
                .setTag(Constants.BOBBLIFICATION)
                .build()
                .startDownload(new DownloadListener() {
                    @Override
                    public void onDownloadComplete() {
                        checkIfBothImageDownloaded();
                    }

                    @Override
                    public void onError(ANError error) {
                        ErrorHandlerUtil.logError(error, "maskImageDownloader");
                        if (error != null) {
                            mBobblificationListener.onError(error.getErrorDetail());
                        } else {
                            mBobblificationListener.onError("onError");
                        }
                    }
                });
    }

    private void checkIfBothImageDownloaded() {
        numberOfImageDownloaded++;
        if (numberOfImageDownloaded == 2) {
            new CreateBobbleHeads().execute();
        }
    }

    private class CreateBobbleHeads extends AsyncTask<Void, Void, Long> {

        @Override
        protected Long doInBackground(Void... voids) {
            Face face = new Face(null, gender, featuresPoints.toString(), "dlibv1");
            FaceRepository.insertOrUpdate(BobbleSDK.getContext(), face);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            final Bitmap originalBitmap = BitmapFactory.decodeFile(dirPath + File.separator + bobbleFileName);
            try {
                double rotateAngle = -Math.atan((double) (featuresPoints.getJSONObject("1").getInt("y") - featuresPoints.getJSONObject("0").getInt("y")) / (double) (featuresPoints.getJSONObject("1").getInt("x") - featuresPoints.getJSONObject("0").getInt("x"))) * 180 / Math.PI;
                InputStream inputStream = FileUtil.getStream(dirPath + File.separator + maskFileName);
                final BobbleComposedMask mask = new BobbleComposedMask(inputStream);
                for (int i = 0; i < numOfMasks; i++) {
                    final String path = BobbleUtils.getDirPath() + File.separator + BobbleUtils.getUniqueFileName("bobbleHead", ".png");
                    final Bitmap maskBitmap = Bitmap.createScaledBitmap(mask.getDecomposedBobbleMask(i), originalBitmap.getWidth(), originalBitmap.getHeight(), false);
                    Bitmap extractedFace = Bitmap.createBitmap(originalBitmap.getWidth(), originalBitmap.getHeight(), Bitmap.Config.ARGB_8888);
                    final Canvas extractedFaceCanvas = new Canvas(extractedFace);
                    extractedFaceCanvas.drawBitmap(originalBitmap, 0, 0, null);
                    extractedFaceCanvas.drawBitmap(maskBitmap, 0, 0, paint);
                    final JSONArray jsonArray = maskROIArray.getJSONArray(i);
                    extractedFace = Bitmap.createBitmap(extractedFace, jsonArray.getInt(0), jsonArray.getInt(1), jsonArray.getInt(2), jsonArray.getInt(3));
                    float[] chinPoint = {featuresPoints.getJSONObject("11").getInt("x") - jsonArray.getInt(0), featuresPoints.getJSONObject("11").getInt("y") - jsonArray.getInt(1)};
                    Matrix matrix = new Matrix();
                    matrix.setRotate((float) rotateAngle, extractedFace.getWidth() / 2, extractedFace.getHeight() / 2);
                    RectF rectF = new RectF(0, 0, extractedFace.getWidth(), extractedFace.getHeight());
                    matrix.mapRect(rectF);
                    matrix.mapPoints(chinPoint);
                    Bitmap rotatedBitmap = Bitmap.createBitmap((int) rectF.width(), (int) rectF.height(), extractedFace.getConfig());
                    Canvas canvas = new Canvas(rotatedBitmap);
                    canvas.drawBitmap(extractedFace, matrix, null);
                    BobbleUtils.saveImage(rotatedBitmap, path);
                    chinPoint[0] = chinPoint[0] / rotatedBitmap.getWidth();
                    chinPoint[1] = 1 - (chinPoint[1] / rotatedBitmap.getHeight());
                    final BobbleHead bobbleHead = new BobbleHead(null, path, chinPoint[0], chinPoint[1], 1000 - i, face.getId());
                    BobbleHeadRepository.insertOrUpdate(BobbleSDK.getContext(), bobbleHead);
                    FileUtil.delete(path + File.separator + maskFileName);
                    FileUtil.delete(path + File.separator + bobbleFileName);
                }
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
            return face.getId();
        }

        @Override
        protected void onPostExecute(Long integer) {
            if (integer != null) {
                mBobblificationListener.onBobblificationComplete(integer);
            } else {
                mBobblificationListener.onError("errorWhileBobbleHeadCreation");
            }
        }
    }

}
