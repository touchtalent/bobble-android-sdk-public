package me.bobbleapp.sdk.model;

import com.google.gson.JsonObject;

/**
 * Created by amitshekhar on 16/01/16.
 */
public class ColorConfig {

    private String toneHex;
    private String shadeHex;
    private String highlightHex;

    public ColorConfig(String toneHex, String shadeHex, String highlightHex) {
        this.toneHex = toneHex;
        this.shadeHex = shadeHex;
        this.highlightHex = highlightHex;
    }

    public ColorConfig() {
    }

    public String toJsonObjectString() {
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("toneHex", toneHex);
        jsonObject.addProperty("shadeHex", shadeHex);
        jsonObject.addProperty("highlightHex", highlightHex);
        return jsonObject.toString();
    }
}
