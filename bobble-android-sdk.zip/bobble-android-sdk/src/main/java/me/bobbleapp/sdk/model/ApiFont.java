package me.bobbleapp.sdk.model;

/**
 * Created by amitshekhar on 22/01/16.
 */
public class ApiFont {
    private long fontId;
    private String fontFileUrl;

    public long getFontId() {
        return fontId;
    }

    public void setFontId(long fontId) {
        this.fontId = fontId;
    }

    public String getFontFileUrl() {
        return fontFileUrl;
    }

    public void setFontFileUrl(String fontFileUrl) {
        this.fontFileUrl = fontFileUrl;
    }
}
