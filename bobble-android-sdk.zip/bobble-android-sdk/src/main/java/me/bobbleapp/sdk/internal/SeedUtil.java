package me.bobbleapp.sdk.internal;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.Font;
import me.bobbleapp.sdk.database.Sticker;
import me.bobbleapp.sdk.database.StickerBackground;
import me.bobbleapp.sdk.database.StickerCategory;
import me.bobbleapp.sdk.database.StickerCharacter;
import me.bobbleapp.sdk.database.StickerText;
import me.bobbleapp.sdk.database.TextStyle;
import me.bobbleapp.sdk.database.repository.FontRepository;
import me.bobbleapp.sdk.database.repository.StickerBackgroundRepository;
import me.bobbleapp.sdk.database.repository.StickerCategoryRepository;
import me.bobbleapp.sdk.database.repository.StickerCharacterRepository;
import me.bobbleapp.sdk.database.repository.StickerRepository;
import me.bobbleapp.sdk.database.repository.StickerTextRepository;
import me.bobbleapp.sdk.database.repository.TextStyleRepository;
import me.bobbleapp.sdk.interfaces.SeedListener;
import me.bobbleapp.sdk.model.ApiFont;
import me.bobbleapp.sdk.model.ApiSticker;
import me.bobbleapp.sdk.model.ApiStickerBackground;
import me.bobbleapp.sdk.model.ApiStickerCategory;
import me.bobbleapp.sdk.model.ApiStickerCharacter;
import me.bobbleapp.sdk.model.ApiStickerText;
import me.bobbleapp.sdk.model.ApiTextStyle;
import me.bobbleapp.sdk.model.SeedModel;
import me.bobbleapp.sdk.networking.Networking;

/**
 * Created by amitshekhar on 24/06/16.
 */
public class SeedUtil {

    public static void seed(final Context context, final int rawResId, final String zipPath, final SeedListener seedListener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    BLog.d("seed start");
                    final String unZipPath = BobbleSDK.getContext().getExternalFilesDir(null) + File.separator + "seed";
                    if (!FileUtil.mkdirs(unZipPath, true)) {
                        BLog.d("failed to create unzip folder.");
                        if (seedListener != null) {
                            seedListener.onError("errorWhileSeeding");
                        }
                        return;
                    }
                    ZipInputStream zin = null;
                    if (zipPath == null) {
                        InputStream inputStream = context.getResources().openRawResource(rawResId);
                        zin = new ZipInputStream(inputStream);
                    } else {
                        FileInputStream fin = new FileInputStream(zipPath);
                        zin = new ZipInputStream(fin);
                    }
                    ZipEntry ze = null;
                    while ((ze = zin.getNextEntry()) != null) {
                        String entryName = ze.getName();

                        String entryPath = unZipPath + "/" + entryName;
                        if (ze.isDirectory()) {
                            FileUtil.mkdirs(entryPath);
                        } else {
                            if (!FileUtil.create(entryPath, true)) {
                                continue;
                            }
                            FileOutputStream fOut = new FileOutputStream(entryPath);
                            byte[] buffer = new byte[ZipUtil.BUFFER_SIZE];
                            int len;
                            while ((len = zin.read(buffer)) != -1) {
                                fOut.write(buffer, 0, len);
                            }
                            fOut.close();
                            zin.closeEntry();
                        }
                    }
                    zin.close();
                    if (zipPath != null) {
                        FileUtil.delete(zipPath);
                    }
                    BLog.d("unzip done");
                    final String jsonPath = unZipPath + File.separator + Constants.SEED_MAIN_FOLDER + File.separator + Constants.SEED_JSON_FILE;
                    final String resourcesPath = unZipPath + File.separator + Constants.SEED_MAIN_FOLDER + File.separator + Constants.SEED_RESOURCES_FOLDER;

                    File jsonFile = new File(jsonPath);
                    FileInputStream stream = new FileInputStream(jsonFile);
                    String jsonString = null;
                    try {
                        FileChannel fc = stream.getChannel();
                        MappedByteBuffer bb = fc.map(FileChannel.MapMode.READ_ONLY, 0, fc.size());
                        jsonString = Charset.defaultCharset().decode(bb).toString();
                    } finally {
                        stream.close();
                    }

                    BLog.d("json read done");

                    Gson gson = new GsonBuilder().create();
                    final SeedModel seedModel = gson.fromJson(jsonString, SeedModel.class);

                    BLog.d("object mapping done");

                    if (seedModel != null && seedModel.getFonts() != null) {
                        for (ApiFont apiFont : seedModel.getFonts()) {
                            Font font = new Font(apiFont);
                            Font tempFont = FontRepository.getFontForId(BobbleSDK.getContext(), font.getId());
                            if (tempFont != null) {
                                font.setLocalPath(tempFont.getLocalPath());
                            }
                            FontRepository.insertOrUpdate(BobbleSDK.getContext(), font);
                            if (font.getLocalPath() == null) {
                                Networking.downloadFont(font);
                            }
                        }
                    }
                    if (seedModel != null && seedModel.getTextStyles() != null) {
                        for (ApiTextStyle apiTextStyle : seedModel.getTextStyles()) {
                            TextStyle textStyle = new TextStyle(apiTextStyle);
                            TextStyleRepository.insertOrUpdate(BobbleSDK.getContext(), textStyle);
                        }
                    }
                    if (seedModel != null && seedModel.getStickerBackgrounds() != null) {
                        for (ApiStickerBackground apiStickerBackground : seedModel.getStickerBackgrounds()) {
                            StickerBackground stickerBackground = new StickerBackground(apiStickerBackground);
                            if (FileUtil.exists(resourcesPath + File.separator + apiStickerBackground.getStickerBackgroundImage())) {
                                stickerBackground.setLocalImage(resourcesPath + File.separator + apiStickerBackground.getStickerBackgroundImage());
                            }
                            StickerBackgroundRepository.insertOrUpdate(BobbleSDK.getContext(), stickerBackground);
                        }
                    }
                    if (seedModel != null && seedModel.getStickerCharacters() != null) {
                        for (ApiStickerCharacter apiStickerCharacter : seedModel.getStickerCharacters()) {
                            StickerCharacter stickerCharacter = new StickerCharacter(apiStickerCharacter);
                            if (FileUtil.exists(resourcesPath + File.separator + apiStickerCharacter.getStickerCharacterImage())) {
                                stickerCharacter.setLocalImage(resourcesPath + File.separator + apiStickerCharacter.getStickerCharacterImage());
                            }
                            StickerCharacterRepository.insertOrUpdate(BobbleSDK.getContext(), stickerCharacter);
                        }
                    }
                    if (seedModel != null && seedModel.getStickerTexts() != null) {
                        for (ApiStickerText apiStickerText : seedModel.getStickerTexts()) {
                            StickerText stickerText = new StickerText(apiStickerText);
                            if (FileUtil.exists(resourcesPath + File.separator + apiStickerText.getStickerTextImage())) {
                                stickerText.setLocalImage(resourcesPath + File.separator + apiStickerText.getStickerTextImage());
                            }
                            StickerTextRepository.insertOrUpdate(BobbleSDK.getContext(), stickerText);
                        }
                    }
                    if (seedModel != null && seedModel.getStickers() != null) {
                        for (ApiSticker apiSticker : seedModel.getStickers()) {
                            Sticker sticker = new Sticker(apiSticker);
                            StickerRepository.insertOrUpdate(BobbleSDK.getContext(), sticker);
                        }
                    }
                    if (seedModel != null && seedModel.getStickerCategories() != null) {
                        for (ApiStickerCategory apiStickerCategory : seedModel.getStickerCategories()) {
                            StickerCategory stickerCategory = new StickerCategory(apiStickerCategory);
                            if (FileUtil.exists(resourcesPath + File.separator + apiStickerCategory.getStickerCategoryImage())) {
                                stickerCategory.setLocalImage(resourcesPath + File.separator + apiStickerCategory.getStickerCategoryImage());
                            }
                            StickerCategoryRepository.insertOrUpdate(BobbleSDK.getContext(), stickerCategory);
                        }
                    }
                    BLog.d("seed done");
                    if (seedListener != null) {
                        seedListener.onSeedCompletion();
                    }
                } catch (Exception e) {
                    if (seedListener != null) {
                        seedListener.onError("errorWhileSeeding");
                    }
                }
            }
        }).start();
    }

}
