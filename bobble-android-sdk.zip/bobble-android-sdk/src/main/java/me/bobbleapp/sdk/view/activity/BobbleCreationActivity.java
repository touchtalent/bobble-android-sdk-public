package me.bobbleapp.sdk.view.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.R;
import me.bobbleapp.sdk.interfaces.FragmentCallback;
import me.bobbleapp.sdk.internal.BLog;
import me.bobbleapp.sdk.internal.Constants;
import me.bobbleapp.sdk.view.fragment.BobbleProgressFragment;
import me.bobbleapp.sdk.view.fragment.GenderSelectionFragment;
import me.bobbleapp.sdk.view.fragment.ImagePickerFragment;

/**
 * Created by amitshekhar on 25/07/16.
 */
public class BobbleCreationActivity extends AppCompatActivity implements FragmentCallback {

    private static final String TAG = BobbleCreationActivity.class.getSimpleName();
    private Bitmap inputBitmap;

    @NonNull
    public static Intent newIntent(@NonNull Context context) {
        return new Intent(context, BobbleCreationActivity.class);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        BLog.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bobble_creation);
        openFragment("camera");
    }

    @Override
    protected void onStop() {
        BLog.d(TAG, "onStop");
        super.onStop();
    }

    @Override
    protected void onResume() {
        BLog.d(TAG, "onResume");
        super.onResume();
    }

    @Override
    protected void onStart() {
        BLog.d(TAG, "onStart");
        super.onStart();
    }

    @Override
    protected void onPause() {
        BLog.d(TAG, "onPause");
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        BLog.d(TAG, "onDestroy");
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        BLog.d(TAG, "onBackPressed");
        int numberOfFragments = getSupportFragmentManager().getBackStackEntryCount();
        BLog.d(TAG, "numberOfFragments : " + numberOfFragments);
        if (numberOfFragments > 1) {
            BobbleProgressFragment bobbleProgressFragment = (BobbleProgressFragment) getSupportFragmentManager().findFragmentByTag(Constants.BOBBLE_PROCESS_FRAGMENT);
            if (bobbleProgressFragment != null && bobbleProgressFragment.isVisible()) {
                bobbleProgressFragment.cancelBobblification();
                bobbleProgressFragment.deleteFace();
            }
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
            setResult(RESULT_CANCELED);
            finish();
            releaseInputBitmap();
        }
    }

    public void openFragment(String type) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        switch (type) {
            case "camera":
                ImagePickerFragment imagePickerFragment = new ImagePickerFragment();
                fragmentTransaction.replace(R.id.fragmentContainer, imagePickerFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
                break;
            case "genderSelection":
                GenderSelectionFragment genderSelectionFragment = new GenderSelectionFragment();
                fragmentTransaction.replace(R.id.fragmentContainer, genderSelectionFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                break;
        }
    }

    @Override
    public Bitmap getInputBitmap() {
        return inputBitmap;
    }

    @Override
    public void setInputBitmap(Bitmap bitmap) {
        this.inputBitmap = bitmap;
    }

    @Override
    public void finishBobbleCreationProcess(long faceId) {
        setResult(RESULT_OK, new Intent().putExtra(BobbleSDK.FACE_ID, faceId));
        finish();
        releaseInputBitmap();
    }

    @Override
    public void releaseInputBitmap() {
        try {
            if (inputBitmap != null) {
                inputBitmap.recycle();
                inputBitmap = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
