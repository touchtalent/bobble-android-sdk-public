package me.bobbleapp.sdk.faceselector.cropwindow.handle;

import android.graphics.Rect;

import me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge;

/**
 * HandleHelper class to handle vertical handles (i.e. left and right handles).
 */
class VerticalHandleHelper extends HandleHelper {

    // Member Variables ////////////////////////////////////////////////////////

    private me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge mEdge;

    // Constructor /////////////////////////////////////////////////////////////

    VerticalHandleHelper(me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge edge) {
        super(null, edge);
        mEdge = edge;
    }

    // HandleHelper Methods ////////////////////////////////////////////////////

    @Override
    void updateCropWindow(float x,
                          float y,
                          float targetAspectRatio,
                          Rect imageRect,
                          float snapRadius) {

        // Adjust this Edge accordingly.
        mEdge.adjustCoordinate(x, y, imageRect, snapRadius, targetAspectRatio);

        float left = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.LEFT.getCoordinate();
        float top = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.TOP.getCoordinate();
        float right = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.RIGHT.getCoordinate();
        float bottom = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.BOTTOM.getCoordinate();

        // After this Edge is moved, our crop window is now out of proportion.
        final float targetHeight = me.bobbleapp.sdk.faceselector.util.AspectRatioUtil.calculateHeight(left, right, targetAspectRatio);
        final float currentHeight = bottom - top;

        // Adjust the crop window so that it maintains the given aspect ratio by
        // moving the adjacent edges symmetrically in or out.
        final float difference = targetHeight - currentHeight;
        final float halfDifference = difference / 2;
        top -= halfDifference;
        bottom += halfDifference;

        me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.TOP.setCoordinate(top);
        me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.BOTTOM.setCoordinate(bottom);

        // Check if we have gone out of bounds on the top or bottom, and fix.
        if (me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.TOP.isOutsideMargin(imageRect, snapRadius) && !mEdge.isNewRectangleOutOfBounds(Edge.TOP,
                imageRect,
                targetAspectRatio)) {
            final float offset = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.TOP.snapToRect(imageRect);
            me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.BOTTOM.offset(-offset);
            mEdge.adjustCoordinate(targetAspectRatio);
        }
        if (me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.BOTTOM.isOutsideMargin(imageRect, snapRadius) && !mEdge.isNewRectangleOutOfBounds(Edge.BOTTOM,
                imageRect,
                targetAspectRatio)) {
            final float offset = me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.BOTTOM.snapToRect(imageRect);
            me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.TOP.offset(-offset);
            mEdge.adjustCoordinate(targetAspectRatio);
        }
    }
}
