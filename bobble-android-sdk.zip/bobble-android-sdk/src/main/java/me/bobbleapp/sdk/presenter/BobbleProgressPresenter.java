package me.bobbleapp.sdk.presenter;

import android.graphics.Bitmap;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.BobbleHead;
import me.bobbleapp.sdk.interfaces.BobblificationListener;
import me.bobbleapp.sdk.internal.BLog;
import me.bobbleapp.sdk.internal.BobbleUtils;
import me.bobbleapp.sdk.view.BobbleProgressView;

/**
 * Created by Prashant Gupta on 29-07-2016.
 */
public class BobbleProgressPresenter implements Presenter {

    private final String TAG = BobbleProgressPresenter.class.getSimpleName();
    private BobbleProgressView bobbleProgressView;

    public BobbleProgressPresenter() {

    }

    public void setView(BobbleProgressView bobbleProgressView) {
        this.bobbleProgressView = bobbleProgressView;
    }

    public void onFinish() {
        this.bobbleProgressView.onFinish();
    }

    public void bobblify(Bitmap bitmap, String gender) {
        BobbleSDK.bobblify(bitmap, gender, new BobblificationListener() {
            @Override
            public void onBobblificationComplete(long faceId) {
                try {
                    BLog.d(TAG, "bobble created successfully for : " + faceId);
                    BobbleHead bobbleHead = BobbleSDK.getPreferredBobbleHeadForFaceId(faceId);
                    String path = bobbleHead.getLocalImage();
                    Bitmap bobble = BobbleUtils.getLocalImage(BobbleProgressPresenter.this.bobbleProgressView.context(), path);
                    BobbleProgressPresenter.this.bobbleProgressView.bobbleCompletion(faceId, bobble);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String error) {
                BLog.d(TAG, "error creating bobble head : " + error);
                if (error.equals("requestCancelledError")) {
                    return;
                }
                try {
                    BobbleProgressPresenter.this.bobbleProgressView.bobbleError(error);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void deleteFace(long faceId) {
        if (faceId != 0) {
            BobbleSDK.deleteFace(faceId, null);
        }
    }

    public void cancelBobblification() {
        BobbleSDK.cancelBobblification();
    }

    @Override
    public void resume() {

    }

    @Override
    public void pause() {

    }

    @Override
    public void destroy() {
        this.bobbleProgressView = null;
    }

    @Override
    public void stop() {

    }

    @Override
    public void start() {

    }
}
