package me.bobbleapp.sdk.view.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.io.File;

import me.bobbleapp.sdk.R;
import me.bobbleapp.sdk.animation.PuffInAnimation;
import me.bobbleapp.sdk.animation.ScaleInAnimation;
import me.bobbleapp.sdk.interfaces.FragmentCallback;
import me.bobbleapp.sdk.internal.BLog;
import me.bobbleapp.sdk.internal.BobbleUtils;
import me.bobbleapp.sdk.internal.Constants;
import me.bobbleapp.sdk.internal.UserPicture;
import me.bobbleapp.sdk.presenter.ImagePickerPresenter;
import me.bobbleapp.sdk.view.ImagePickerView;

/**
 * Created by amitshekhar on 25/07/16.
 */
public class ImagePickerFragment extends Fragment implements ImagePickerView, View.OnClickListener {

    private static final String TAG = ImagePickerFragment.class.getSimpleName();
    private static final int SELECT_PICTURE = 9009;
    private static final int REQUEST_IMAGE_CAPTURE = 9010;
    private static final String IMAGE_TYPE = "image/*";
    private Uri imageUri;
    private ImagePickerPresenter presenter;
    private LinearLayout buttonOpenCamera, buttonOpenGallery;
    private ImageView imageViewOne, imageViewTwo, imageViewThree, imageViewOneQuality, imageViewTwoQuality, imageViewThreeQuality;
    private Animation pulseAnimation;
    private FragmentCallback fragmentCallback;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        BLog.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        presenter = new ImagePickerPresenter();
        pulseAnimation = AnimationUtils.loadAnimation(getActivity().getApplicationContext(), R.anim.pulse_standard);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        BLog.d(TAG, "onCreateView");
        View view = inflater.inflate(R.layout.fragment_bobble_image_picker, container, false);
        setOnClickListeners(view);
        return view;
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        BLog.d(TAG, "onViewCreated");
        super.onViewCreated(view, savedInstanceState);
        fragmentCallback.releaseInputBitmap();
        presenter.setView(this);
        animateEducationUI();
    }

    @Override
    public void onAttach(Context context) {
        BLog.d(TAG, "onAttach");
        super.onAttach(context);
        try {
            fragmentCallback = (FragmentCallback) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement FragmentCallback");
        }
    }

    @Override
    public void onStop() {
        BLog.d(TAG, "onStop");
        super.onStop();
        presenter.stop();
    }

    @Override
    public void onResume() {
        BLog.d(TAG, "onResume");
        super.onResume();
        presenter.resume();
    }

    @Override
    public void onStart() {
        BLog.d(TAG, "onStart");
        super.onStart();
        presenter.start();
    }

    @Override
    public void onPause() {
        BLog.d(TAG, "onPause");
        super.onPause();
        presenter.pause();
    }

    @Override
    public void onDestroy() {
        BLog.d(TAG, "onDestroy");
        super.onDestroy();
        presenter.destroy();
        presenter = null;
        pulseAnimation = null;
    }

    @Override
    public void onDestroyView() {
        BLog.d(TAG, "onDestroyView");
        super.onDestroyView();
    }

    @Override
    public Context context() {
        return getActivity().getApplicationContext();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == AppCompatActivity.RESULT_OK) {
                fragmentCallback.setInputBitmap(new UserPicture(imageUri, getActivity().getContentResolver()).getBitmap());
                if (fragmentCallback.getInputBitmap() != null) {
                    openFragment("genderSelection");
                }
            } else if (requestCode == SELECT_PICTURE && resultCode == AppCompatActivity.RESULT_OK) {
                if (data != null) {
                    imageUri = data.getData();
                    fragmentCallback.setInputBitmap(new UserPicture(imageUri, getActivity().getContentResolver()).getBitmap());
                    if (fragmentCallback.getInputBitmap() != null) {
                        openFragment("faceSelection");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View view) {
        final int id = view.getId();
        if (id == R.id.buttonOpenCamera) {
            BLog.d(TAG, "buttonOpenCamera clicked");
            dispatchTakePictureIntent();
        } else if (id == R.id.buttonOpenGallery) {
            BLog.d(TAG, "buttonOpenGallery clicked");
            Intent intent = new Intent();
            intent.setType(IMAGE_TYPE);
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, getString(R.string.select_picture)), SELECT_PICTURE);
        } else if (id == R.id.imageViewOne) {
            buttonOpenCamera.startAnimation(pulseAnimation);
        } else if (id == R.id.imageViewTwo) {
            buttonOpenCamera.startAnimation(pulseAnimation);
        } else if (id == R.id.imageViewThree) {
            buttonOpenCamera.startAnimation(pulseAnimation);
        }
    }

    private void setOnClickListeners(View view) {
        buttonOpenCamera = (LinearLayout) view.findViewById(R.id.buttonOpenCamera);
        buttonOpenGallery = (LinearLayout) view.findViewById(R.id.buttonOpenGallery);
        imageViewOne = (ImageView) view.findViewById(R.id.imageViewOne);
        imageViewTwo = (ImageView) view.findViewById(R.id.imageViewTwo);
        imageViewThree = (ImageView) view.findViewById(R.id.imageViewThree);
        imageViewOneQuality = (ImageView) view.findViewById(R.id.imageViewOneQuality);
        imageViewTwoQuality = (ImageView) view.findViewById(R.id.imageViewTwoQuality);
        imageViewThreeQuality = (ImageView) view.findViewById(R.id.imageViewThreeQuality);
        buttonOpenCamera.setOnClickListener(this);
        buttonOpenGallery.setOnClickListener(this);
        imageViewOne.setOnClickListener(this);
        imageViewTwo.setOnClickListener(this);
        imageViewThree.setOnClickListener(this);
    }

    private void animateEducationUI() {
        imageViewOneQuality.setVisibility(View.INVISIBLE);
        imageViewTwoQuality.setVisibility(View.INVISIBLE);
        imageViewThreeQuality.setVisibility(View.INVISIBLE);
        buttonOpenCamera.setVisibility(View.INVISIBLE);
        buttonOpenGallery.setVisibility(View.INVISIBLE);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                new ScaleInAnimation(buttonOpenCamera).animate();
                new ScaleInAnimation(buttonOpenGallery).animate();
                new PuffInAnimation(imageViewOneQuality).animate();
                new PuffInAnimation(imageViewTwoQuality).animate();
                new PuffInAnimation(imageViewThreeQuality).animate();
            }
        }, 300);
    }

    public void dispatchTakePictureIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File photo = new File(BobbleUtils.getDirPath(), "bobble_image.jpg");
        imageUri = Uri.fromFile(photo);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
    }

    public void openFragment(String type) {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        switch (type) {
            case "faceSelection":
                FaceSelectionFragment faceSelectionFragment = new FaceSelectionFragment();
                fragmentTransaction.replace(R.id.fragmentContainer, faceSelectionFragment);
                fragmentTransaction.addToBackStack(Constants.IMAGE_PICKER_BACK_STACK);
                fragmentTransaction.commit();
                getActivity().getWindow().addFlags(
                        WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
                getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                break;
            case "genderSelection":
                GenderSelectionFragment genderSelectionFragment = new GenderSelectionFragment();
                fragmentTransaction.replace(R.id.fragmentContainer, genderSelectionFragment);
                fragmentTransaction.addToBackStack(Constants.IMAGE_PICKER_BACK_STACK);
                fragmentTransaction.commit();
                getActivity().getWindow().addFlags(
                        WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
                getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                break;
        }
    }

}
