package me.bobbleapp.sdk.database.repository;

import android.content.Context;

import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.StickerBackground;
import me.bobbleapp.sdk.database.StickerBackgroundDao;

public class StickerBackgroundRepository {

    public static void insertOrUpdate(Context context, StickerBackground stickerBackground) {
        getStickerBackgroundDao(context).insertOrReplace(stickerBackground);
    }

    public static void clearStickerBackgrounds(Context context) {
        getStickerBackgroundDao(context).deleteAll();
    }

    public static boolean isEmpty(Context context) {
        return (getStickerBackgroundDao(context).count() == 0);
    }

    public static void deleteStickerBackgroundWithId(Context context, long id) {
        getStickerBackgroundDao(context).delete(getStickerBackgroundForId(context, id));
    }

    public static List<StickerBackground> getAllStickerBackgrounds(Context context) {
        return getStickerBackgroundDao(context).loadAll();
    }

    public static StickerBackground getStickerBackgroundForId(Context context, long id) {
        return getStickerBackgroundDao(context).load(id);
    }

    public static StickerBackgroundDao getStickerBackgroundDao(Context c) {
        return BobbleSDK.getDaoSession().getStickerBackgroundDao();
    }
}
