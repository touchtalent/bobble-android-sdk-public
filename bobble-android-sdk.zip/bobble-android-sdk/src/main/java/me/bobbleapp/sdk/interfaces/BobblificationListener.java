package me.bobbleapp.sdk.interfaces;

/**
 * Created by amitshekhar on 16/01/16.
 */
public interface BobblificationListener {
    void onBobblificationComplete(long faceId);

    void onError(String error);

}
