package me.bobbleapp.sdk.internal;

import android.graphics.Bitmap;
import android.os.AsyncTask;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.interfaces.BobblificationListener;
import me.bobbleapp.sdk.networking.Networking;

/**
 * Created by amitshekhar on 16/01/16.
 */
public class BobbleImageHandler extends AsyncTask<Void, Void, Void> {

    private final BobblificationListener mBobblificationListener;
    private Bitmap bitmap;
    private String path;
    private final String gender;
    private static final int BITMAP_HEIGHT = 1200;

    public BobbleImageHandler(Bitmap bitmap, String gender, BobblificationListener bobblificationListener) {
        this.bitmap = bitmap;
        this.mBobblificationListener = bobblificationListener;
        this.gender = gender;
    }

    public BobbleImageHandler(String path, String gender, BobblificationListener bobblificationListener) {
        this.path = path;
        this.gender = gender;
        this.mBobblificationListener = bobblificationListener;
    }


    @Override
    protected Void doInBackground(Void... voids) {
        if (bitmap != null) {
            final double ratio = (double) bitmap.getHeight() / bitmap.getWidth();
            if (bitmap.getHeight() > BITMAP_HEIGHT) {
                final int width = (int) (BITMAP_HEIGHT / ratio);
                bitmap = Bitmap.createScaledBitmap(bitmap, width, BITMAP_HEIGHT, true);
            }
            path = BobbleUtils.saveImageTemporarily(bitmap);
        } else {
            bitmap = BobbleUtils.decodeSampledBitmapFromFile(path, BITMAP_HEIGHT, BITMAP_HEIGHT);
            path = BobbleUtils.saveImageTemporarily(bitmap);
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        Networking.bobblifyMaskBobble(BobbleSDK.getContext(), path, gender, mBobblificationListener);
    }

}
