package me.bobbleapp.sdk.internal;

/**
 * Created by amitshekhar on 15/01/16.
 */

/**
 * An Exception indicating that the Bobble SDK has not been correctly initialized.
 */
public class BobbleSdkNotInitializedException extends BobbleException {
    static final long serialVersionUID = 1;

    /**
     * Constructs a BobbleSdkNotInitializedException with no additional information.
     */
    public BobbleSdkNotInitializedException() {
        super();
    }

    /**
     * Constructs a BobbleSdkNotInitializedException with a message.
     *
     * @param message A String to be returned from getMessage.
     */
    public BobbleSdkNotInitializedException(String message) {
        super(message);
    }

    /**
     * Constructs a BobbleSdkNotInitializedException with a message and inner error.
     *
     * @param message   A String to be returned from getMessage.
     * @param throwable A Throwable to be returned from getCause.
     */
    public BobbleSdkNotInitializedException(String message, Throwable throwable) {
        super(message, throwable);
    }

    /**
     * Constructs a BobbleSdkNotInitializedException with an inner error.
     *
     * @param throwable A Throwable to be returned from getCause.
     */
    public BobbleSdkNotInitializedException(Throwable throwable) {
        super(throwable);
    }
}