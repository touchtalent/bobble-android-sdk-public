package me.bobbleapp.sdk.internal;

/**
 * Created by amitshekhar on 12/01/16.
 */
public final class Constants {
    public static final String TAG = "BobbleSDK";
    public static final int SUCCESS = 1;
    public static final int ERROR = 0;
    public static final String IS_USER_REGISTERED = "isUserRegistered";
    public static final String BOBBLE_SDK_VERSION = "1";
    public static final String BOBBLE_TYPE = "bobbleType";
    public static final String ENABLE_SDK = "enableSDK";
    public static final String DATABASE_NAME = "bobbleSdk-db";
    public static final int EMOJI_HEIGHT = 600;
    public static final String STICKER = "sticker";
    public static final String STICKER_CATEGORY = "sticker_category";
    public static final String BOBBLE_HEAD = "bobble_head";
    public static final String FACE = "face";
    public static final String SEED_MAIN_FOLDER = "bobble_sdk_seed";
    public static final String SEED_RESOURCES_FOLDER = "resources";
    public static final String SEED_JSON_FILE = "seed.json";
    public static final String IMAGE_PICKER_BACK_STACK = "image_picker_back_stack";
    public static final String BOBBLE_PROCESS_FRAGMENT = "bobble_process_fragment";
    public static final String NO_FACE_DETECTED_ERROR = "noFaceDetected";
    public static final String CONNECTION_ERROR = "connectionError";
    public static final String BOBBLIFICATION = "bobblification";
}