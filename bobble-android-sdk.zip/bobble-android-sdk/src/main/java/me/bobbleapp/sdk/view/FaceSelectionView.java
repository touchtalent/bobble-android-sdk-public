package me.bobbleapp.sdk.view;

import android.graphics.Bitmap;

/**
 * Created by amitshekhar on 27/07/16.
 */
public interface FaceSelectionView extends BaseView {

    void singleFaceDetection();

    void multipleFaceDetection();

    void noFaceDetection();

    void navigate();

    void rotate(Bitmap bitmap);

    void onRotateError();
}
