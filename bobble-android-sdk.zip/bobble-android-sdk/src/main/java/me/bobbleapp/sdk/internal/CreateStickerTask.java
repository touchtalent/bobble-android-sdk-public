package me.bobbleapp.sdk.internal;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;

import org.json.JSONArray;
import org.json.JSONException;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.R;
import me.bobbleapp.sdk.database.BobbleHead;
import me.bobbleapp.sdk.database.Sticker;
import me.bobbleapp.sdk.database.StickerCharacter;
import me.bobbleapp.sdk.database.StickerText;
import me.bobbleapp.sdk.database.TextStyle;
import me.bobbleapp.sdk.database.WaterMark;
import me.bobbleapp.sdk.database.repository.WaterMarkRepository;
import me.bobbleapp.sdk.interfaces.StickerCreationListener;

/**
 * Created by Prashant Gupta on 23-01-2016.
 */
public class CreateStickerTask extends AsyncTask<Void, Void, Bitmap> {

    private final String TAG = "CreateStickerTask";
    private BobbleHead bobbleHead;
    private String text;
    private StickerCreationListener stickerCreationListener;
    private Sticker sticker;
    private Bitmap backgroundBitmap;
    private Bitmap bobbleBitmap;
    private Bitmap characterBitmap;
    private Bitmap textBitmap;
    private Bitmap resizedFace;
    private Bitmap waterMarkBitmap;
    private Bitmap mainBitmap;
    int layoutHeight = 0, startingTop = 0;
    StaticLayout layout = null, layoutTextStroke;

    public CreateStickerTask(BobbleHead bobbleHead, Sticker sticker, StickerCreationListener stickerCreationListener, String text) {
        this.bobbleHead = bobbleHead;
        this.sticker = sticker;
        this.text = text;
        this.stickerCreationListener = stickerCreationListener;
    }

    @Override
    protected Bitmap doInBackground(Void... params) {

        try {
            StickerCharacter stickerCharacter = sticker.getStickerCharacter();

            backgroundBitmap = BobbleUtils.getLocalImage(BobbleSDK.getContext(), sticker.getStickerBackground().getLocalImage());

            int bgHeight = backgroundBitmap.getHeight();
            int bgWidth = backgroundBitmap.getWidth();

            mainBitmap = Bitmap.createBitmap(backgroundBitmap.getWidth(), backgroundBitmap.getHeight(), Bitmap.Config.RGB_565);

            Canvas canvas = new Canvas(mainBitmap);
            Paint paint = new Paint();

            if (sticker.getBackgroundColor() == null)
                canvas.drawColor(Color.WHITE);
            else
                canvas.drawColor(Color.parseColor(sticker.getBackgroundColor()));

            bobbleBitmap = BobbleUtils.getLocalImage(BobbleSDK.getContext(), bobbleHead.getLocalImage());

            getOriginalSticker(stickerCharacter, canvas, paint, bgWidth, bgHeight);

            if (sticker.getWaterMark() != null) {
                WaterMark waterMark = WaterMarkRepository.getWaterMarkForImageUrl(BobbleSDK.getContext(), sticker.getWaterMark());
                if (waterMark != null && waterMark.getLocalPath() != null) {
                    waterMarkBitmap = BobbleUtils.getLocalImage(BobbleSDK.getContext(), waterMark.getLocalPath());
                }
            }
            if (waterMarkBitmap == null) {
                waterMarkBitmap = BitmapFactory.decodeResource(BobbleSDK.getContext().getResources(), R.drawable.ic_bobble_default_watermark);
                waterMarkBitmap = waterMarkBitmap.createScaledBitmap(waterMarkBitmap, 80, 40, false);
            } else {
                waterMarkBitmap = waterMarkBitmap.createScaledBitmap(waterMarkBitmap, (int) (0.50 * waterMarkBitmap.getWidth()), (int) (0.50 * waterMarkBitmap.getHeight()), false);
            }
            canvas.drawBitmap(waterMarkBitmap, canvas.getWidth() - waterMarkBitmap.getWidth() - BobbleUtils.dpToPx(5, BobbleSDK.getContext()), canvas.getHeight() - waterMarkBitmap.getHeight() - BobbleUtils.dpToPx(5, BobbleSDK.getContext()), null);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return mainBitmap;
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);

        if (characterBitmap != null) {
            characterBitmap.recycle();
        }
        if (textBitmap != null) {
            textBitmap.recycle();
        }
        if (backgroundBitmap != null) {
            backgroundBitmap.recycle();
        }
        if (resizedFace != null) {
            resizedFace.recycle();
        }
        if (bobbleBitmap != null) {
            bobbleBitmap.recycle();
        }

        if (waterMarkBitmap != null) {
            waterMarkBitmap.recycle();
        }

        if (bitmap == null) {
            stickerCreationListener.onError("Some error occurred");
        } else {
            stickerCreationListener.onStickerCreationComplete(bitmap);
        }

    }

    private void getOriginalSticker(StickerCharacter stickerCharacter, Canvas canvas, Paint paint, int bgWidth, int bgHeight) {
        float ratio = (float) bgWidth / Constants.EMOJI_HEIGHT;
        int faceHeight = 250;
        if (stickerCharacter != null && stickerCharacter.getFaceHeight() != null && stickerCharacter.getFaceHeight() != 0) {
            faceHeight = stickerCharacter.getFaceHeight();
        }
        faceHeight = (int) (ratio * faceHeight);
        final float faceScaleRatio = (float) bobbleBitmap.getHeight() / bobbleBitmap.getWidth();
        final int faceWidth = (int) (faceHeight / faceScaleRatio);

        characterBitmap = BobbleUtils.getLocalImage(BobbleSDK.getContext(), stickerCharacter.getLocalImage());
        if (characterBitmap.getWidth() != bgWidth || characterBitmap.getHeight() != bgHeight)
            characterBitmap = Bitmap.createScaledBitmap(characterBitmap, bgWidth, bgHeight, false);

        textBitmap = null;
        if (text == null) {
            StickerText stickerText = sticker.getStickerText();
            textBitmap = BobbleUtils.getLocalImage(BobbleSDK.getContext(), stickerText.getLocalImage());
            if (textBitmap.getWidth() != bgWidth || textBitmap.getHeight() != bgHeight)
                textBitmap = Bitmap.createScaledBitmap(textBitmap, bgWidth, bgHeight, false);
        } else if (text != null) {
            paintOTFText(ratio, stickerCharacter);
        }

        resizedFace = resizeBitmapWithMatrix(faceWidth, faceHeight);
        int left;
        int top;
        Matrix matrix = new Matrix();
        left = (int) ((stickerCharacter.getFaceX() * ratio - faceWidth * bobbleHead.getFaceOverNeckX()));
        top = (int) ((stickerCharacter.getFaceY() * ratio - faceHeight) + faceHeight * bobbleHead.getFaceOverNeckY());
        matrix.postRotate(90 - stickerCharacter.getFaceAngle(), faceWidth * bobbleHead.getFaceOverNeckX(), faceHeight * (1 - bobbleHead.getFaceOverNeckY()));
        matrix.postTranslate(left, top);

        if (sticker.getStickerLayerOrders() == null) {
            sticker.setStickerLayerOrders("[\"background\",\"text\",\"character\",\"face\"]");
        }

        if (sticker.getStickerLayerOrders() != null) {
            try {
                JSONArray jsonArray = new JSONArray(sticker.getStickerLayerOrders());
                for (int i = 0; i < jsonArray.length(); i++) {
                    switch (jsonArray.getString(i)) {
                        case "background":
                            canvas.drawBitmap(backgroundBitmap, 0, 0, paint);
                            break;
                        case "text":
                            if (text == null || layout == null) {
                                if (textBitmap != null) {
                                    canvas.drawBitmap(textBitmap, 0, 0, paint);
                                }
                            } else if (text != null) {
                                canvas.rotate(90 - stickerCharacter.getTextAngle(), -stickerCharacter.getTextLeft() * ratio + layout.getWidth() / 2, startingTop + layoutHeight / 2);
                                canvas.drawBitmap(textBitmap, 0, 0, paint);
                                canvas.rotate(stickerCharacter.getTextAngle() - 90, -stickerCharacter.getTextLeft() * ratio + layout.getWidth() / 2, startingTop + layoutHeight / 2);
                            }
                            break;
                        case "character":
                            canvas.drawBitmap(characterBitmap, 0, 0, paint);
                            break;
                        case "face":
                            canvas.drawBitmap(resizedFace, matrix, new Paint(Paint.FILTER_BITMAP_FLAG));
                            break;
                    }
                }
            } catch (JSONException e) {

            }
        }
    }

    public Bitmap resizeBitmapWithMatrix(int newWidth, int newHeight) {
        Bitmap scaledBitmap = Bitmap.createBitmap(newWidth, newHeight, Bitmap.Config.ARGB_8888);

        float ratioX = newWidth / (float) bobbleBitmap.getWidth();
        float ratioY = newHeight / (float) bobbleBitmap.getHeight();
        float middleX = newWidth / 2.0f;
        float middleY = newHeight / 2.0f;

        Matrix scaleMatrix = new Matrix();
        scaleMatrix.setScale(ratioX, ratioY, middleX, middleY);

        Canvas canvas = new Canvas(scaledBitmap);
        canvas.setMatrix(scaleMatrix);
        canvas.drawBitmap(bobbleBitmap, middleX - bobbleBitmap.getWidth() / 2, middleY - bobbleBitmap.getHeight() / 2, new Paint(Paint.FILTER_BITMAP_FLAG));

        return scaledBitmap;

    }

    private void paintOTFText(float ratio, StickerCharacter stickerCharacter) {
        if (text != null && !text.isEmpty()) {
            textBitmap = Bitmap.createBitmap(backgroundBitmap.getWidth(), backgroundBitmap.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas tcanvas = new Canvas(textBitmap);
            int width = (int) (ratio * (stickerCharacter.getTextRight() - stickerCharacter.getTextLeft()));
            int height = (int) (ratio * (stickerCharacter.getTextBottom() - stickerCharacter.getTextTop()));
            TextStyle textStyle = sticker.getTextStyle();
            int textSize = textStyle.getTextSize();
            TextPaint textPaint = new TextPaint();
            textPaint.setAntiAlias(true);
            textPaint.setColor(Color.parseColor(textStyle.getTextColor()));
            textPaint.setTypeface(BobbleUtils.getTypeface(BobbleSDK.getContext(), textStyle.getFontId()));
            textPaint.setStyle(Paint.Style.FILL);
            boolean readyForWidth = true;
            do {
                textPaint.setTextSize(textSize);

                String[] list = text.split(" ");
                for (String s : list) {
                    float m = textPaint.measureText(s);
                    if (m > width) {
                        textSize = textSize - 5;
                        readyForWidth = false;
                        break;
                    } else {
                        readyForWidth = true;
                    }
                }
            } while (!readyForWidth);

            boolean readyForHeight = true;
            do {
                textPaint.setTextSize(textSize);
                layout = new StaticLayout(text, textPaint, width, Layout.Alignment.ALIGN_CENTER, 1, 0, true);
                layoutHeight = layout.getHeight();

                if (layoutHeight > height) {
                    textSize = textSize - 5;
                    readyForHeight = false;
                } else {
                    readyForHeight = true;
                }
            } while (!readyForHeight);

            startingTop = (int) (stickerCharacter.getTextTop() * ratio + (height - layoutHeight) / 2);
            tcanvas.translate(stickerCharacter.getTextLeft() * ratio, startingTop);

            TextPaint textPaintStroke = new TextPaint();
            textPaintStroke.setTextSize(textSize);
            textPaintStroke.setAntiAlias(true);
            textPaintStroke.setTypeface(BobbleUtils.getTypeface(BobbleSDK.getContext(), textStyle.getFontId()));
            textPaintStroke.setStrokeJoin(Paint.Join.ROUND);
            textPaintStroke.setStyle(Paint.Style.STROKE);

            try {
                if (textStyle.getShowStroke2() && textStyle.getColorStroke2() != null && textStyle.getSizeStroke2() != null) {
                    String strokeColorHex2 = textStyle.getColorStroke2();
                    int strokeWidthPer2 = textStyle.getSizeStroke2();
                    textPaintStroke.setStrokeWidth((int) ((float) layout.getHeight() * strokeWidthPer2 * 0.01));
                    textPaintStroke.setColor(Color.parseColor(strokeColorHex2));
                    layoutTextStroke = new StaticLayout(text, textPaintStroke, width, Layout.Alignment.ALIGN_CENTER, 1, 0, true);
                    layoutTextStroke.draw(tcanvas);
                }
                if (textStyle.getShowStroke1() && textStyle.getColorStroke1() != null && textStyle.getSizeStroke1() != null) {
                    String strokeColorHex1 = textStyle.getColorStroke1();
                    int strokeWidthPer1 = textStyle.getSizeStroke1();
                    textPaintStroke.setStrokeWidth((int) ((float) layout.getHeight() * strokeWidthPer1 * 0.01));
                    textPaintStroke.setColor(Color.parseColor(strokeColorHex1));
                    layoutTextStroke = new StaticLayout(text, textPaintStroke, width, Layout.Alignment.ALIGN_CENTER, 1, 0, true);
                    layoutTextStroke.draw(tcanvas);
                }
            } catch (Exception e) {
                BLog.d("stroking exception " + e);
            }
            layout.draw(tcanvas);
            tcanvas.translate(-stickerCharacter.getTextLeft() * ratio, -startingTop);
            if (textStyle.getShowShadow()) {
                textBitmap = BobbleUtils.applyShadow(textBitmap, textStyle.getColorShadow(), (int) (textStyle.getRadiusShadow() * ratio), (int) (textStyle.getDxShadow() * ratio), (int) (textStyle.getDyShadow() * ratio), BlurMaskFilter.Blur.valueOf(textStyle.getTypeShadow().toUpperCase()));
            }
        }
    }

}
