package me.bobbleapp.sdk.database.repository;

import android.content.Context;

import java.util.List;

import me.bobbleapp.sdk.BobbleSDK;
import me.bobbleapp.sdk.database.StickerCategory;
import me.bobbleapp.sdk.database.StickerCategoryDao;

public class StickerCategoryRepository {

    public static void insertOrUpdate(Context context, StickerCategory stickerCategory) {
        getStickerCategoryDao(context).insertOrReplace(stickerCategory);
    }

    public static void clearStickerCategories(Context context) {
        getStickerCategoryDao(context).deleteAll();
    }

    public static boolean isEmpty(Context context) {
        return (getStickerCategoryDao(context).count() == 0);
    }

    public static void deleteStickerCategoryWithId(Context context, long id) {
        getStickerCategoryDao(context).delete(getStickerCategoryForId(context, id));
    }

    public static List<StickerCategory> getAllStickerCategories(Context context) {
        return getStickerCategoryDao(context).loadAll();
    }

    public static StickerCategory getStickerCategoryForId(Context context, long id) {
        return getStickerCategoryDao(context).load(id);
    }

    public static StickerCategoryDao getStickerCategoryDao(Context c) {
        return BobbleSDK.getDaoSession().getStickerCategoryDao();
    }
}
