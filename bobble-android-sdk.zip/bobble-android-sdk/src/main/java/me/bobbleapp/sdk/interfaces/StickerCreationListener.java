package me.bobbleapp.sdk.interfaces;

import android.graphics.Bitmap;

/**
 * Created by amitshekhar on 19/01/16.
 */
public interface StickerCreationListener {
    void onStickerCreationComplete(Bitmap bitmap);

    void onError(String error);
}
