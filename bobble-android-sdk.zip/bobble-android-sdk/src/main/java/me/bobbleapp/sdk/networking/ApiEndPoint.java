package me.bobbleapp.sdk.networking;

/**
 * Created by amitshekhar on 29/07/16.
 */
public final class ApiEndPoint {

    private static final String BASE_URL = "https://client-api.bobbleapp.me/v1";
    private static final String BOBBLIFY_BASE_URL = "https://bobblification-sdk.bobbleapp.me/api/v1";

    public static final String REGISTER = BASE_URL + "/users/register";
    public static final String USERS_CONFIG = BASE_URL + "/users/getConfig";
    public static final String NEW_STICKER_PACKS = BASE_URL + "/stickerCategories/newAdditions";
    public static final String STICKER_PACK_RESOURCE = BASE_URL + "/stickerCategories/{id}/download";
    public static final String BOBBLIFY = BOBBLIFY_BASE_URL + "/bobblification/masking";

}
