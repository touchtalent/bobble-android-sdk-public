

package me.bobbleapp.sdk.faceselector.cropwindow.handle;

import android.graphics.Rect;

/**
 * Enum representing a pressable, draggable Handle on the crop window.
 */
public enum Handle {

    TOP_LEFT(new me.bobbleapp.sdk.faceselector.cropwindow.handle.CornerHandleHelper(me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.TOP, me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.LEFT)),
    TOP_RIGHT(new me.bobbleapp.sdk.faceselector.cropwindow.handle.CornerHandleHelper(me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.TOP, me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.RIGHT)),
    BOTTOM_LEFT(new me.bobbleapp.sdk.faceselector.cropwindow.handle.CornerHandleHelper(me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.BOTTOM, me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.LEFT)),
    BOTTOM_RIGHT(new me.bobbleapp.sdk.faceselector.cropwindow.handle.CornerHandleHelper(me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.BOTTOM, me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.RIGHT)),
    LEFT(new me.bobbleapp.sdk.faceselector.cropwindow.handle.VerticalHandleHelper(me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.LEFT)),
    TOP(new HorizontalHandleHelper(me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.TOP)),
    RIGHT(new me.bobbleapp.sdk.faceselector.cropwindow.handle.VerticalHandleHelper(me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.RIGHT)),
    BOTTOM(new HorizontalHandleHelper(me.bobbleapp.sdk.faceselector.cropwindow.edge.Edge.BOTTOM)),
    CENTER(new me.bobbleapp.sdk.faceselector.cropwindow.handle.CenterHandleHelper());

    // Member Variables ////////////////////////////////////////////////////////

    private HandleHelper mHelper;

    // Constructors ////////////////////////////////////////////////////////////

    Handle(HandleHelper helper) {
        mHelper = helper;
    }

    // Public Methods //////////////////////////////////////////////////////////

    public void updateCropWindow(float x,
                                 float y,
                                 Rect imageRect,
                                 float snapRadius) {

        mHelper.updateCropWindow(x, y, imageRect, snapRadius);
    }

    public void updateCropWindow(float x,
                                 float y,
                                 float targetAspectRatio,
                                 Rect imageRect,
                                 float snapRadius) {

        mHelper.updateCropWindow(x, y, targetAspectRatio, imageRect, snapRadius);
    }
}
