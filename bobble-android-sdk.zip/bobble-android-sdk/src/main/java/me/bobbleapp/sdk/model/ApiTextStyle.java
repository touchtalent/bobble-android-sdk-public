package me.bobbleapp.sdk.model;

/**
 * Created by amitshekhar on 22/01/16.
 */
public class ApiTextStyle {

    private long textStyleId;
    private int textStyleFontSize;
    private String textStyleFontColor;
    private boolean textStyleShowStroke1;
    private String textStyleStroke1Color;
    private int textStyleStroke1Width;
    private boolean textStyleShowStroke2;
    private String textStyleStroke2Color;
    private int textStyleStroke2Width;
    private boolean textStyleShowShadow;
    private int textStyleShadowX;
    private int textStyleShadowY;
    private String textStyleShadowColor;
    private int textStyleShadowRadius;
    private String textStyleShadowType;
    private long textStyleFont;

    public long getTextStyleId() {
        return textStyleId;
    }

    public void setTextStyleId(long textStyleId) {
        this.textStyleId = textStyleId;
    }

    public int getTextStyleFontSize() {
        return textStyleFontSize;
    }

    public void setTextStyleFontSize(int textStyleFontSize) {
        this.textStyleFontSize = textStyleFontSize;
    }

    public String getTextStyleFontColor() {
        return textStyleFontColor;
    }

    public void setTextStyleFontColor(String textStyleFontColor) {
        this.textStyleFontColor = textStyleFontColor;
    }

    public boolean isTextStyleShowStroke1() {
        return textStyleShowStroke1;
    }

    public void setTextStyleShowStroke1(boolean textStyleShowStroke1) {
        this.textStyleShowStroke1 = textStyleShowStroke1;
    }

    public String getTextStyleStroke1Color() {
        return textStyleStroke1Color;
    }

    public void setTextStyleStroke1Color(String textStyleStroke1Color) {
        this.textStyleStroke1Color = textStyleStroke1Color;
    }

    public int getTextStyleStroke1Width() {
        return textStyleStroke1Width;
    }

    public void setTextStyleStroke1Width(int textStyleStroke1Width) {
        this.textStyleStroke1Width = textStyleStroke1Width;
    }

    public boolean isTextStyleShowStroke2() {
        return textStyleShowStroke2;
    }

    public void setTextStyleShowStroke2(boolean textStyleShowStroke2) {
        this.textStyleShowStroke2 = textStyleShowStroke2;
    }

    public String getTextStyleStroke2Color() {
        return textStyleStroke2Color;
    }

    public void setTextStyleStroke2Color(String textStyleStroke2Color) {
        this.textStyleStroke2Color = textStyleStroke2Color;
    }

    public int getTextStyleStroke2Width() {
        return textStyleStroke2Width;
    }

    public void setTextStyleStroke2Width(int textStyleStroke2Width) {
        this.textStyleStroke2Width = textStyleStroke2Width;
    }

    public boolean isTextStyleShowShadow() {
        return textStyleShowShadow;
    }

    public void setTextStyleShowShadow(boolean textStyleShowShadow) {
        this.textStyleShowShadow = textStyleShowShadow;
    }

    public int getTextStyleShadowX() {
        return textStyleShadowX;
    }

    public void setTextStyleShadowX(int textStyleShadowX) {
        this.textStyleShadowX = textStyleShadowX;
    }

    public int getTextStyleShadowY() {
        return textStyleShadowY;
    }

    public void setTextStyleShadowY(int textStyleShadowY) {
        this.textStyleShadowY = textStyleShadowY;
    }

    public String getTextStyleShadowColor() {
        return textStyleShadowColor;
    }

    public void setTextStyleShadowColor(String textStyleShadowColor) {
        this.textStyleShadowColor = textStyleShadowColor;
    }

    public int getTextStyleShadowRadius() {
        return textStyleShadowRadius;
    }

    public void setTextStyleShadowRadius(int textStyleShadowRadius) {
        this.textStyleShadowRadius = textStyleShadowRadius;
    }

    public String getTextStyleShadowType() {
        return textStyleShadowType;
    }

    public void setTextStyleShadowType(String textStyleShadowType) {
        this.textStyleShadowType = textStyleShadowType;
    }

    public long getTextStyleFont() {
        return textStyleFont;
    }

    public void setTextStyleFont(long textStyleFont) {
        this.textStyleFont = textStyleFont;
    }
}
